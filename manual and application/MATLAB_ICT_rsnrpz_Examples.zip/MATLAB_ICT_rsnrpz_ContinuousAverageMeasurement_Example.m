%% Rohde & Schwarz GmbH & Co. KG
% Example of using rsnrpz VXIpnp driver version 3.5.6.0 or newer with rsnrpz.mdd MATLAB driver

% The example zeroes the sensor, sets it to a continuous average mode and measures one value

%% Opening the session
try
    % Create a device object, open the first sensor you find
    nrpz = icdevice('rsnrpz.mdd', 'USB::0xAAD::*?');

    % Connect device object to the instrument.
    connect(nrpz)
    
catch ME 
    % Clean-up driver session
    % Delete object
    if exist ('nrpz')
        delete(nrpz);
    end
    
    error('Connection to the instrument failed:\n%s', ME.message)
end

%% Zeroing the sensor
fprintf('Zeroing sensor ')
invoke (nrpz, 'chan_zero', 1)

% Wait until the zeroing is complete
zeroingComplete = 0;
tic
while zeroingComplete == 0
    zeroingComplete = invoke (nrpz, 'chan_isZeroComplete', 1);
    fprintf('x')
    if toc > 10.0
        throw(MException('Zeroing:Timeout', '\nZeroing timeout, make sure no signal is applied at the sensor input'));
    end
    pause(0.1);
end
fprintf(' finished\n')

%% Setting of the ContAVG parameters
fprintf('Applying settings ... ')
invoke (nrpz, 'chan_mode', 1, 0); % continuous average
invoke (nrpz, 'avg_configureAvgAuto', 1, 3); % auto averaging, with defined resolution
invoke (nrpz, 'chan_setCorrectionFrequency', 1, 100E6); % Correction Frequency 100 MHz
invoke (nrpz, 'trigger_setSource', 1, 3) % trigger source immediate
invoke (nrpz, 'chan_setContAvSmoothingEnabled', 1, 0); % smoothing OFF
fprintf('finished\n')
%% Measurement of one value

% Initiate the measurement
fprintf('Initiated Measurement ')
invoke (nrpz, 'chan_initiate', 1)

% Wait until the measurement has finished
measurementComplete = 0;
tic
while measurementComplete == 0
    measurementComplete = invoke (nrpz, 'chan_isMeasurementComplete', 1);
    fprintf('x')
    if toc > 5.0
        throw(MException('Measuring:Timeout', '\nNRPZ measurement timeout'));
    end
    pause(0.01);
end
fprintf(' finished\n')

% Read the result
measurement = invoke (nrpz, 'meass_fetchMeasurement', 1);
fprintf('Measured Power: %0.12f W (%0.3f dBm)\n\n', measurement, 10*log10(measurement));

%% Clean-up driver session
if exist ('nrpz')
    % Disconnect device object from hardware.
    disconnect(nrpz);
    % Delete object
    delete(nrpz);
end