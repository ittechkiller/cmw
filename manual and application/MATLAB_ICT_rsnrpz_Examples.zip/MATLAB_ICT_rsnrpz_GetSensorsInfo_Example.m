%% Rohde & Schwarz GmbH & Co. KG
% Example of using rsnrpz VXIpnp driver version 3.5.6.0 or newer with rsnrpz.mdd MATLAB driver
% The example retrieves the information about all the available R&S NRP-Z and NRP-S/SN Powersensors (connected over USB)
% Then, as an example of use, it initiates two separate connections to two sensors and performs zeroing on both of them.
%% Establishing connection

%% Opening the session of the 1st powersensor.
% The reason being, that for the methods GetSensorCount() and GetSensorInfo(), MATLAB needs a connected object.
% Therefore, we use the first found sensor as the auxiliary connected object and we close it afterwards.
try
    % Create a device object.
    auxNRPZobject = icdevice('rsnrpz.mdd', 'USB::0xAAD::*?');

    % Connect device object to the instrument.
    connect(auxNRPZobject)
    
catch ME 
    % Clean-up driver session
    % Delete object
    if exist ('dummyNRPZobject')
        delete(auxNRPZobject);
    end
    
    error('Connection to the instrument failed:\n%s', ME.message)
end

% Find out sensors count and retrieve their info

sensorCount = invoke (auxNRPZobject, 'GetSensorCount');
fprintf('Number of sensors found: %d\n\n', sensorCount);
resourceNames = {};
% Loop through the sensors count to list all the sensors
for index = 1:sensorCount
    
    [resourceName, type, serialNumber] = invoke (auxNRPZobject, 'GetSensorInfo', index);
    resourceNames{end+1} = resourceName;
    fprintf('Sensor number %d:\nResourceName = "%s"\nType = "%s"\nSerialNumber = "%s"\n\n', index, resourceName, type, serialNumber);
end

% Clean-up the auxiliary sensor session
if exist ('auxNRPZobject')
    % Disconnect device object from hardware.
    disconnect(auxNRPZobject);
    % Delete object
    delete(auxNRPZobject);
end

%% Here, you can open sessions to every one of your sensors.
% Assuming you have at least two sensors, open two independent sessions and always use channel parameter = 1:
if (sensorCount < 2)
    error('To continue with opening two sessions, you need at least two sensors to be present');
end

% Initiate the session sensorOne
try    
    sensorOne = icdevice('rsnrpz.mdd', resourceNames{1});
    connect(sensorOne);
catch ME 
    % Clean-up driver session
    % Delete object
    if exist ('sensorOne')
        delete(sensorOne);
    end
    
    error('Connection to the sensor "%s" failed:\n%s', resourceNames{1}, ME.message)
end

% Initiate the session sensorTwo
try    
    sensorTwo = icdevice('rsnrpz.mdd', resourceNames{2});
    connect(sensorTwo);
catch ME 
    % Clean-up driver session
    % Delete object
    if exist ('sensorTwo')
        delete(sensorTwo);
    end
    
    error('Connection to the sensor "%s" failed:\n%s', resourceNames{2}, ME.message)
end

% Zeroing sensors
invoke (sensorOne, 'chan_zero', 1);
invoke (sensorTwo, 'chan_zero', 1);

% Paralell start of zeroing both sensors
% Wait until the zeroing is complete for both of them
fprintf('\nZeroing both sensors ');
zeroingComplete1 = 0;
zeroingComplete2 = 0;
tic
while zeroingComplete1 == 0 || zeroingComplete2 == 0
    zeroingComplete1 = invoke (sensorOne, 'chan_isZeroComplete', 1);
    zeroingComplete2 = invoke (sensorTwo, 'chan_isZeroComplete', 1);
    if (zeroingComplete1 == 0 && zeroingComplete2 == 0)
        fprintf('X');
    else if (zeroingComplete1 == 1 || zeroingComplete2 == 1)
        fprintf('x');
        end
    end
    
    if toc > 10.0
        throw(MException('Zeroing:Timeout', '\nZeroing timeout, make sure no signal is applied at the sensor inputs'));
    end
    pause(0.1);
end
fprintf(' finished\n')

