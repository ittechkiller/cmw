%% Rohde & Schwarz GmbH & Co. KG
% Example of using rsnrpz VXIpnp driver version 3.5.6.0 or newer with rsnrpz.mdd MATLAB driver
% The example shows how to use two powersensors with:
% - Zeroing them paralelly
% - Setting them to a continuous average mode
% - Measuring one value on each paralelly

% Before you start this script, change both ResourceStrings to fit your Powersensors.
% You can use the script MATLAB_ICT_rsnrpz_GetSensorsInfo_Example.m to find out the ResourceStrings

%% Connecting to the both Powersensors

resourceNameOne = 'USB::0x0aad::0x0139::101460';
resourceNameTwo = 'USB::0x0aad::0x0023::102800';
avgResolution = 3; % Range 1-4, the higher resolution, the more stable results, but longer measurement time

% Initiate the session sensorOne
try    
    sensorOne = icdevice('rsnrpz.mdd', resourceNameOne);
    fprintf('\nConnecting to the sensor 1 "%s" ...', resourceNameOne);
    connect(sensorOne);
    invoke (sensorOne, 'chan_reset', 1);
    fprintf(' finished\n');
catch ME 
    % Clean-up driver session
    % Delete object
    if exist ('sensorOne')
        delete(sensorOne);
    end
    
    error('Connection to the sensor "%s" failed:\n%s', resourceNameOne, ME.message)
end

% Initiate the session sensorTwo
try    
    sensorTwo = icdevice('rsnrpz.mdd', resourceNameTwo);
    fprintf('Connecting to the sensor 2 "%s" ...', resourceNameTwo);
    connect(sensorTwo);
    invoke (sensorTwo, 'chan_reset', 1);
    fprintf(' finished\n');
catch ME 
    % Clean-up driver session
    % Delete object
    if exist ('sensorTwo')
        delete(sensorTwo);
    end
    
    error('Connection to the sensor "%s" failed:\n%s', resourceNameTwo, ME.message)
end

%% Zeroing both sensors
invoke (sensorOne, 'chan_zero', 1);
invoke (sensorTwo, 'chan_zero', 1);

% Paralell start of zeroing both sensors
% Wait until the zeroing is complete for both of them
fprintf('\nZeroing both sensors ');
zeroingComplete1 = 0;
zeroingComplete2 = 0;
tic
while zeroingComplete1 == 0 || zeroingComplete2 == 0
    zeroingComplete1 = invoke (sensorOne, 'chan_isZeroComplete', 1);
    zeroingComplete2 = invoke (sensorTwo, 'chan_isZeroComplete', 1);
    if (zeroingComplete1 == 0 && zeroingComplete2 == 0)
        fprintf('X');
    else if (zeroingComplete1 == 1 || zeroingComplete2 == 1)
        fprintf('x');
        end
    end
    
    if toc > 10.0
        throw(MException('Zeroing:Timeout', '\nZeroing timeout, make sure no signal is applied at the sensor inputs'));
    end
    pause(0.1);
end
fprintf(' finished\n');


%% Setting of the ContAVG parameters for sensor 1:
fprintf('\nApplying settings to the sensor 1 ... ');
invoke (sensorOne, 'chan_mode', 1, 0); % continuous average
invoke (sensorOne, 'avg_configureAvgAuto', 1, avgResolution); % auto averaging, with defined resolution
invoke (sensorOne, 'chan_setCorrectionFrequency', 1, 100E6); % Correction Frequency 100 MHz
invoke (sensorOne, 'trigger_setSource', 1, 3); % trigger source immediate
invoke (sensorOne, 'chan_setContAvSmoothingEnabled', 1, 0); % smoothing OFF
fprintf('finished\n');

%% Setting of the ContAVG parameters for sensor 2:
fprintf('Applying settings to the sensor 2 ... ');
invoke (sensorTwo, 'chan_mode', 1, 0); % continuous average
invoke (sensorTwo, 'avg_configureAvgAuto', 1, avgResolution); % auto averaging, with defined resolution
invoke (sensorTwo, 'chan_setCorrectionFrequency', 1, 100E6); % Correction Frequency 100 MHz
invoke (sensorTwo, 'trigger_setSource', 1, 3) % trigger source immediate
invoke (sensorTwo, 'chan_setContAvSmoothingEnabled', 1, 0); % smoothing OFF
fprintf('finished\n');
%% Measurement of one value

fprintf('\nInitiated Measurements on both sensors:\n');
invoke (sensorOne, 'chan_initiate', 1);
invoke (sensorTwo, 'chan_initiate', 1);

% Wait until both measurements have finished
measurement1Complete = 0;
measurement2Complete = 0;
charCounter = 0;
tic
while measurement1Complete == 0 || measurement2Complete == 0
    
    fprintf('x');
    charCounter = charCounter + 1;
    if (charCounter > 50)
        charCounter = 0;
        fprintf('\n');
    end
    
    if (measurement1Complete == 0)
        measurement1Complete = invoke (sensorOne, 'chan_isMeasurementComplete', 1);
        if (measurement1Complete > 0)
            fprintf('\nSensor 1 Measurement complete\n');
            charCounter = 0;
        end
    end
    
    if (measurement2Complete == 0)
        measurement2Complete = invoke (sensorTwo, 'chan_isMeasurementComplete', 1);
        if (measurement2Complete > 0)
            fprintf('\nSensor 2 Measurement complete\n');
            charCounter = 0;
        end
    end
       
    if toc > 5.0
        fprintf('\n');
        throw(MException('Measurement:Timeout', '\nMeasurement timeout'));
    end
    pause(0.01);
end

% Read the results
measurement1 = invoke (sensorOne, 'meass_fetchMeasurement', 1);
fprintf('\nSensor 1 measured power: %0.12f W (%0.3f dBm)\n', measurement1, 10*log10(measurement1));

measurement2 = invoke (sensorTwo, 'meass_fetchMeasurement', 1);
fprintf('Sensor 2 measured power: %0.12f W (%0.3f dBm)\n\n', measurement2, 10*log10(measurement2));

%% Clean-up driver sessions
if exist ('sensorOne')
    % Disconnect device object from hardware.
    disconnect(sensorOne);
    % Delete object
    delete(sensorOne);
end

if exist ('sensorTwo')
    % Disconnect device object from hardware.
    disconnect(sensorTwo);
    % Delete object
    delete(sensorTwo);
end