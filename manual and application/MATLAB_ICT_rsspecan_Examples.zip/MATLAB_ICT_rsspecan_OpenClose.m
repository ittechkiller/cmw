%% Opening the session
try
    % Create a device object.
    specan = icdevice('rsspecan.mdd', 'TCPIP::192.168.2.100::INSTR');

    % Connect device object to the instrument.
    connect(specan)
    
catch ME 
    % Clean-up driver session
    % Delete object
    if exist ('specan')
        delete(specan);
    end
    
    error('Connection to the instrument failed:\n%s', ME.message)
end

%% Device communication comes here
    % Query ID response
    idQueryResponse = zeros (1024, 1);
    [idQueryResponse] = invoke (specan, 'IDQueryResponse', 1024, idQueryResponse)

%% Clean-up driver session
if exist ('specan')
    % Disconnect device object from hardware.
    disconnect(specan);
    % Delete object
    delete(specan);
end