%% Opening the session
try
    % Create a device object.
    specan = icdevice('rsspecan.mdd', 'TCPIP::192.168.2.100::INSTR');

    % Connect device object to the instrument.
    connect(specan)
    
catch ME 
    % Clean-up driver session
    % Delete object
    if exist ('specan')
        delete(specan);
    end
    
    error('Connection to the instrument failed:\n%s', ME.message)
end

%% Device communication comes here
    % Query ID response
    idQueryResponse = zeros (1024, 1);
    [idQueryResponse] = invoke (specan, 'IDQueryResponse', 1024, idQueryResponse)
    invoke(specan, 'ConfigureFrequencyCenter', 0, 110E6)
    invoke(specan, 'SetProperty', 'RSSPECAN_ATTR_FREQUENCY_CENTER', 110E6)
    centerFrequency = invoke(specan, 'GetProperty', 'RSSPECAN_ATTR_FREQUENCY_CENTER')
    invoke(specan, 'SetProperty', 'RSSPECAN_ATTR_MARKER_ENABLED', 1, 'M1')
    
    % Setting properties by using different formats of the Property ID
    % Complete Property ID
    invoke(specan, 'SetProperty', 'RSSPECAN_ATTR_FREQUENCY_CENTER', 110E6)
    % Property ID without prefix
    invoke(specan, 'SetProperty', 'ATTR_FREQUENCY_CENTER', 110E6)
    % Property ID case Insensitive
    invoke(specan, 'SetProperty', 'RsSPeCAN_AttR_FrEQuENCy_CeNTeR', 110E6)
    % Descriptive name
    invoke(specan, 'SetProperty', 'Center Frequency', 110E6) 
    % Descriptive name with underscores
    invoke(specan, 'SetProperty', 'Center_Frequency', 110E6) 
    % Descriptive name case insensitive
    invoke(specan, 'SetProperty', 'CeNtEr FrEqUeNcY', 110E6) 


%% Clean-up driver session
if exist ('specan')
    % Disconnect device object from hardware.
    disconnect(specan);
    % Delete object
    delete(specan);
end