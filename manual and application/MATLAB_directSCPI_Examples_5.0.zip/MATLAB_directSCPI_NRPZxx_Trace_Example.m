% The example reads a binary trace from a NRP-Zxx Powersensor. Make sure
% your powersensor supports trace measurements
% Used sensor: NRP-Z86
% Preconditions:
% - Installed R&S VISA 5.11.0 or later with R&S VISA.NET
% - Installed R&S NRP-Toolkit

%% Opening the session
try
    folder = fileparts(which('VISA_Instrument.m'));
    addpath(genpath(folder))
    nrp = VISA_Instrument('RSNRP::0x0095::104015::INSTR'); % Adjust the VISA Resource string to fit your NRP-Zxx powersensor
    nrp.SetTimeoutMilliseconds(7000); % Timeout for VISA Read Operations
catch ME
    error ('Error initializing the instrument:\n%s', ME.message);
end

nrp.Write('*RST');
IDNresponse = nrp.QueryString('*IDN?');
fprintf ('Instrument *IDN? response: "%s"\n', IDNresponse);
nrp.ErrorChecking();

%% Setting of the ContAVG parameters
fprintf('Applying settings ... ')
nrp.Write('INIT:CONT OFF');
nrp.Write('SENS:FUNC "XTIM:POW"');
nrp.Write('SENS:FREQ %f', 1E9);
nrp.Write('SENS:TRAC:POIN %d', 1000);
nrp.Write('SENS:TRAC:TIME %f', 5e-3);
nrp.Write('SENS:TRAC:OFFS:TIME %f', -500e-6);
nrp.Write('TRIG:SOUR IMM');
nrp.Write('SENS:AVER:COUN %d', 16);
nrp.Write('SENS:AVER:STAT ON');
nrp.Write('SENS:AVER:TCON REP');
nrp.Write('FORMAT REAL,32');
nrp.ErrorChecking();
fprintf('finished\n')

%% Measurement of one value
fprintf('Initiated Measurement ...')
nrp.Write('INIT:IMM');

% Wait until the measurement has finished
measuring = 1;
tic
while measuring > 0
    measuring = nrp.QueryInteger('STAT:OPER:COND?');
    fprintf('.')
    if toc > 5.0 % 5 seconds timeout
        fprintf('\n')
        throw(MException('MATLAB_NRPZexample:WaitForMeasurement', 'NRPZ measurement timeout'));
    end
    pause(0.01);
end
fprintf(' measurement finished\n')

traceBIN = nrp.QueryBinaryFloatData('FETCH?');
nrp.ErrorChecking();
traceSize = size(traceBIN);

%Conversion Watt to dBm with the threshold of -90 dBm
traceBIN(traceBIN < 1E-12) = 1E-12;
traceBIN = 10*log10(traceBIN)+30;
fprintf('Plotting the trace of %d points:\n\n', traceSize(2));
plot(traceBIN); % Displaying the trace

%% Clean-up driver session
nrp.Close()