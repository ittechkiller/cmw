% This example does not require MATLAB Instrument Control Toolbox
% It uses .NET assembly called Ivi.Visa
% Preconditions:
% - Installed R&S VISA 5.11.0 or later with R&S VISA.NET
% - Installed R&S NRP-Toolkit

% The example zeroes the NRP-Z powersensor, sets it to a continuous average mode and measures one value

%% Opening the session
try
    folder = fileparts(which('VISA_Instrument.m'));
    addpath(genpath(folder))
    nrp = VISA_Instrument('RSNRP::0x0095::104015::INSTR'); % Adjust the VISA Resource string to fit your NRP-Z powersensor
    nrp.SetTimeoutMilliseconds(7000); % Timeout for NRP VISA Read / Write Operations
catch ME
    
    error ('Error initializing the instrument:\n%s', ME.message);
end

nrp.Write('*RST');
IDNresponse = nrp.QueryString('*IDN?');
fprintf ('Instrument *IDN? response: "%s"\n', IDNresponse);
nrp.ErrorChecking();

%% Setting of the ContAVG parameters
nrp.ClearStatus();
fprintf('Applying settings ... ')
nrp.Write('INIT:CONT OFF');
nrp.Write('SENS:FUNC "POW:AVG"');
nrp.Write('SENS:FREQ %f', 1E9);
nrp.Write('SENS:AVER:COUN:AUTO OFF');
nrp.Write('SENS:AVER:COUN %d', 16);
nrp.Write('SENS:AVER:STAT ON');
nrp.Write('SENS:AVER:TCON REP');
nrp.Write('FORMAT ASCII');
nrp.ErrorChecking();
fprintf('finished\n')

%% Zeroing the sensor
fprintf('Zeroing sensor ...')
nrp.Write('CAL:ZERO:AUTO ONCE'); % The program waits in the Write() until the zeroing is finished
fprintf(' finished\n')

%% Measurement of one value
fprintf('Initiated Measurement ...')
nrp.Write('INIT:IMM');

% Wait until the measurement has finished
measuring = 1;
tic
while measuring > 0
    measuring = nrp.QueryInteger('STAT:OPER:COND?');
    fprintf('.')
    if toc > 5.0 % 5 seconds timeout
        fprintf('\n')
        throw(MException('MATLAB_NRPZexample:WaitForMeasurement', 'NRPZ measurement timeout'));
    end
    pause(0.01);
end
fprintf(' measurement finished\n')
measurement = nrp.QueryASCII_ListOfDoubles('FETCH?', 1);

% Take only the first element, the others are AUX values which are not used in this example
fprintf('Measured Power: %0.12f W (%0.3f dBm)\n\n', measurement, 10*log10(measurement));
nrp.ErrorChecking();

%% Clean-up driver session
nrp.Close()