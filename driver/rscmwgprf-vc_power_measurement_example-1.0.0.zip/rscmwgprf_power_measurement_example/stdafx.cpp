
// stdafx.cpp : source file that includes just the standard includes
// rscmwgprf_power_measurement_example.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"


