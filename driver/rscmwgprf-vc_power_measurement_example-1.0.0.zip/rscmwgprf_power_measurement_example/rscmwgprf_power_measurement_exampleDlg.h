
// rscmwgprf_power_measurement_exampleDlg.h : header file
//

#pragma once
#include "afxwin.h"

// Crscmwgprf_power_measurement_exampleDlg dialog
class Crscmwgprf_power_measurement_exampleDlg : public CDialogEx
{
// Construction
public:
	ViSession m_InstrSession;
	void cleanup (ViBoolean deviceClear);	
	Crscmwgprf_power_measurement_exampleDlg(CWnd* pParent = NULL);	// standard constructor

// Dialog Data
	enum { IDD = IDD_RSCMWGPRF_POWER_MEASUREMENT_EXAMPLE_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support


// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP()
public:	
	
	afx_msg void OnClose();	
	ViStatus rscmwgprf_status;
	CString m_resName;
	BOOL m_IDQuery;
	BOOL m_reset;
	double m_frequency;
	double m_level;
	double m_rms;
	double m_min;
	double m_max;
	afx_msg void OnBnClickedMeasure();
};
