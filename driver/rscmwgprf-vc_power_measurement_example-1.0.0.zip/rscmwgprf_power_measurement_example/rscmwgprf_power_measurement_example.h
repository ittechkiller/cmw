
// rscmwgprf_power_measurement_example.h : main header file for the PROJECT_NAME application
//

#pragma once

#ifndef __AFXWIN_H__
	#error "include 'stdafx.h' before including this file for PCH"
#endif

#include "resource.h"		// main symbols


// Crscmwgprf_power_measurement_exampleApp:
// See rscmwgprf_power_measurement_example.cpp for the implementation of this class
//

class Crscmwgprf_power_measurement_exampleApp : public CWinApp
{
public:
	Crscmwgprf_power_measurement_exampleApp();

// Overrides
public:
	virtual BOOL InitInstance();

// Implementation

	DECLARE_MESSAGE_MAP()
};

extern Crscmwgprf_power_measurement_exampleApp theApp;