
// rscmwgprf_power_measurement_exampleDlg.cpp : implementation file
//

#include "stdafx.h"
#include "rscmwgprf_power_measurement_example.h"
#include "rscmwgprf_power_measurement_exampleDlg.h"
#include "afxdialogex.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#define CHECKERR(fcal) if ((rscmwgprf_status = fcal) < 0)\
					   {\
							cleanup(VI_FALSE);\
							return;\
					   }

// Crscmwgprf_power_measurement_exampleDlg dialog

Crscmwgprf_power_measurement_exampleDlg::Crscmwgprf_power_measurement_exampleDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(Crscmwgprf_power_measurement_exampleDlg::IDD, pParent)
	, m_resName(_T("TCPIP::192.168.5.120::INST"))
	, m_frequency(1000000000)
	, m_level(-10.0)
	, m_rms()
	, m_min()
	, m_max()
	, m_IDQuery(TRUE)
	, m_reset(TRUE)
{
	m_InstrSession = NULL;
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void Crscmwgprf_power_measurement_exampleDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_RES_NAME, m_resName);
	DDX_Check(pDX, IDC_IDQUERY, m_IDQuery);
	DDX_Check(pDX, IDC_RESET, m_reset);
	DDX_Text(pDX, IDC_FREQUENCY, m_frequency);
	DDX_Text(pDX, IDC_LEVEL, m_level);
	DDX_Text(pDX, IDC_RMS, m_rms);
	DDX_Text(pDX, IDC_MIN, m_min);
	DDX_Text(pDX, IDC_MAX, m_max);	
}

BEGIN_MESSAGE_MAP(Crscmwgprf_power_measurement_exampleDlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()	
	ON_BN_CLICKED(ID_MEASURE, &Crscmwgprf_power_measurement_exampleDlg::OnBnClickedMeasure)
END_MESSAGE_MAP()


// Crscmwgprf_power_measurement_exampleDlg message handlers

BOOL Crscmwgprf_power_measurement_exampleDlg::OnInitDialog()
{
	CDialogEx::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here

	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void Crscmwgprf_power_measurement_exampleDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR Crscmwgprf_power_measurement_exampleDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}




/*===========================================================================*/
/* Function: Cleanup
/* Purpose:  Closes the VISA session to the instrument and in case of error
/*           queries the error and shows the dialog box with error message.
/*           In case Device Clear is requested, it is necessary to set the
/*           argument deviceClear to VI_TRUE.
/*===========================================================================*/
void Crscmwgprf_power_measurement_exampleDlg::cleanup(ViBoolean deviceClear)
{
	if (rscmwgprf_status < 0)
	{
		ViChar      error_message[256];
		ViStatus    temp_status;
		CString		message;
		CString		error_string;
		
		/* Query the error message from the instrument driver. This
		 * function gets the error message for VISA and driver failures
		 */
		temp_status = rscmwgprf_error_message(m_InstrSession, rscmwgprf_status, error_message);
		
		if (temp_status == VI_WARN_UNKNOWN_STATUS)
		{
			/* Query the error message from the instrument. This
			 * function gets the error message directly from instrument, like
			 * execution error, out of range error etc.
			 */
			rscmwgprf_error_query(m_InstrSession, &temp_status, error_message);
		}
		error_string = error_message;
		message.Format (_T ("Error 0x%8X occured:\n\n%s"), rscmwgprf_status, error_string);
		AfxMessageBox (message, MB_OK | MB_ICONSTOP); 
	}
	
	/* Device Clear is a low-level command and should be used in case the
	 * instrument is waiting for Operation Complete to cancel the wait.
	 * It is useful for instance in case of incorrect external trigger
	 * when the instrument does not respond to any other command because of
	 * waiting for trigger.
	 */
	if (deviceClear)
	{
		viClear (m_InstrSession);
		viPrintf (m_InstrSession, "*CLS\n");
	}
	
	if (m_InstrSession != NULL)
		rscmwgprf_close (m_InstrSession);

	//GetDlgItem(IDC_SEARCH)->EnableWindow(FALSE);

	HCURSOR cur = LoadCursor ( NULL, IDC_ARROW );
	SetCursor (cur);
}

void Crscmwgprf_power_measurement_exampleDlg::OnClose()
{
	cleanup (VI_FALSE);

	CDialog::OnClose();
}

void Crscmwgprf_power_measurement_exampleDlg::OnBnClickedMeasure()
{
	USES_CONVERSION;
	long rel, count;

	UpdateData ();
	HCURSOR cur = LoadCursor ( NULL, IDC_WAIT );
	SetCursor (cur);
	
	//initialize
	CHECKERR(rscmwgprf_init ((char *) ((LPCTSTR) W2A(m_resName.LockBuffer())), VI_TRUE, VI_TRUE, &m_InstrSession));

	//setup generator
	CHECKERR(rscmwgprf_ConfigureGeneratorMode (m_InstrSession, 1, RSCMWGPRF_VAL_GENMODE_CW));
	CHECKERR(rscmwgprf_ConfigureGeneratorStandAloneScenario (m_InstrSession, 1, RSCMWGPRF_VAL_ANALYZER_CONN_RF1C, RSCMWGPRF_VAL_ANALYZER_SAL_CONV_RX1));
	CHECKERR(rscmwgprf_ConfigureGeneratorFrequencyLevel (m_InstrSession, 1, m_frequency, m_level));
	CHECKERR(rscmwgprf_ConfigureGeneratorState (m_InstrSession, 1, VI_TRUE));

	CHECKERR(rscmwgprf_ConfigureAnalyzerStandAloneScenario (m_InstrSession, 1, RSCMWGPRF_VAL_ANALYZER_CONN_RF1C, RSCMWGPRF_VAL_ANALYZER_SAL_CONV_RX1));
	CHECKERR(rscmwgprf_ConfigureAnalyzer (m_InstrSession, 1, m_level, 0.0, m_frequency));
	CHECKERR(rscmwgprf_ConfigurePwrMeasStatistics (m_InstrSession, 1, RSCMWGPRF_VAL_REPETITION_SINGLE, 20));
	CHECKERR(rscmwgprf_ConfigurePwrMeasTrigger (m_InstrSession, 1, "Free Run", RSCMWGPRF_VAL_TRIGSLOPE_RISING, -30.0, 0.1E-3, RSCMWGPRF_VAL_TRIGMODE_ONCE, 1.0));

	CHECKERR(rscmwgprf_PwrMeasInit (m_InstrSession, 1));

	CHECKERR(rscmwgprf_FetchPwrMeas (m_InstrSession, 1, RSCMWGPRF_VAL_RESULT_CURRENT, RSCMWGPRF_VAL_DETECTOR_RMS, 1, &rel, &m_rms, &count)); 
	CHECKERR(rscmwgprf_FetchPwrMeas (m_InstrSession, 1, RSCMWGPRF_VAL_RESULT_CURRENT, RSCMWGPRF_VAL_DETECTOR_MIN, 1, &rel, &m_min, &count)); 
	CHECKERR(rscmwgprf_FetchPwrMeas (m_InstrSession, 1, RSCMWGPRF_VAL_RESULT_CURRENT, RSCMWGPRF_VAL_DETECTOR_MAX, 1, &rel, &m_max, &count));
	
	cleanup(false);
	
	UpdateData(false);	
	cur = LoadCursor (NULL, IDC_ARROW);
	SetCursor (cur);
}
