README.TXT

Rohde&Schwarz CMWGPRF Program Example for LabVIEW

Power measurement example

Version: 1.1, 12/2012

Contents:

1.0  Introduction

2.0  Prerequisites

3.0  How to use this example

4.0  Known Defects

5.0  Revision History

6.0  Example Files
----------------------------------------------------------------------------

1.0  Introduction

This example explains how to use the LabVIEW Instrument driver.
In the example, the programming language G is used.

2.0  Prerequisites

- National Instruments LabVIEW 2009 (or higher)
- rscmwgprf LabVIEW Instrument Driver

3.0  How to use this example
After installing instrument driver unzip the example, open the example VI.
To use the example, fill in the Resource String (by default it is 
GPIB0::20::INSTR). Configure frequency and level. To start measurement press 
the Start button. Results are shown in table. You may press Start button again 
to start new measurement. Example could be exited by closing the window.

4.0  Known Defects

none

5.0  Revision History

  1.0 12/2009, Petr Zavodny
      Created.
  1.1 8/2012, Petr Zavodny
        Routing settings VI replaced according to driver update.    
		

6.0  Example Files

RSCMWGPRF Power Measurement Example.vi   - Example source code
Configure Generator.vi                   - Utility VI
Configure Measurement.vi                 - Utility VI
readme.txt                     	         - this file

-----------------------------------------------------------------------------
Should you have any technical questions please contact 
the hotline of Rohde & Schwarz Vertriebs-GmbH
Rohde & Schwarz Support Center
e-mail: CustomerSupport@rohde-schwarz.com
-----------------------------------------------------------------------------
