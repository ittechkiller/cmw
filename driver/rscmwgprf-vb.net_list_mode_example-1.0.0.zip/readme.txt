README.TXT

Rohde&Schwarz CMW GPRF Program Example for Visual Basic
List Mode Example

Version: 1.0, 8/2012

Contents:

1.0  Introduction

2.0  Prerequisites

3.0  How to use this example

4.0  Known Defects

5.0  Revision History

6.0  Example Files
----------------------------------------------------------------------------

1.0  Introduction

This example explains how to use the Visual Basic Instrument driver.

2.0  Prerequisites

- Microsoft Visual Studio 2010 (or higher)
- National Instruments NI-488.2 Software 1.60 (or higher) (GPIB only)
- National Instruments VISA 3.0 or Agilent I/O Library 14 (or higher)
- rscmwgprf VXIpnp Instrument Driver

3.0  How to use this example

After installing instrument driver unzip the example and open solution file. 
Add instrument driver wrapper rscmwgprf.cs to the project - wrapper should be located in
<VXIPNPPATH>\winnt\include directory.
Make an executable file and run it.
To use the example, fill in the Resource String (by default it is 
TCPIP::192.168.5.120::INST). To adjust generators settings click on "Settings" button. 
To start example press the "Measure" button. To exit example close window.

4.0  Known Defects

none

5.0  Revision History

1.0, 08/2012, Petr Zavodny
    Created.
		
6.0  Example Files

rscmwgprf_list_mode_example.vb                 - example source code
rscmwgprf_list_mode_example.Designer.vb        - example GUI source code
rscmwgprf_list_mode_example.sln                - example solution file
rscmwgprf_list_mode_example.vbproj             - example project file
rscmwgprf_frequency_level_settings.vb          - generator settings source code
rscmwgprf_frequency_level_settings.Designer.vb - generator settings GUI source code
rscmwgprf_list_mode_example.resx               - cs generated file
rscmwgprf_frequency_level_settings.resx        - cs generated file
AssemblyInfo.vb                                - vb generated file
Resources.resx                                 - vb generated file
Resources.Designer.vb                          - vb generated file
Settings.settings                              - vb generated file
Settings.Designer.vb                           - vb generated file
RS.ico                                         - icon file
readme.txt                                     - this file

-----------------------------------------------------------------------------
Should you have any technical questions please contact 
the hotline of Rohde & Schwarz Vertriebs-GmbH
Rohde & Schwarz Support Center
e-mail: CustomerSupport@rohde-schwarz.com
-----------------------------------------------------------------------------
