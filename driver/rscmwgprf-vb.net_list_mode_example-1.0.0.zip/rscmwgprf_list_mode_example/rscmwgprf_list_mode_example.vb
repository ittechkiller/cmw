﻿Imports rscmwgprf_list_mode_example.InstrumentDriversVB


Public Class rscmwgprf_list_mode_example
    ' Default values of frequency list [Hz]
    Public freqArr = {1000000000.0, 1000000000.0, 1000000000.0, 1000000000.0, 1000000000.0, 1000000000.0, 1000000000.0, 1000000000.0, 1000000000.0, 1000000000.0,
                   2000000000.0, 2000000000.0, 2000000000.0, 2000000000.0, 2000000000.0, 2000000000.0, 2000000000.0, 2000000000.0, 2000000000.0, 2000000000.0,
                   3000000000.0, 3000000000.0, 3000000000.0, 3000000000.0, 3000000000.0, 3000000000.0, 3000000000.0, 3000000000.0, 3000000000.0, 3000000000.0
                    }
    'Default values of level(RMS) list [dBm]
    Public levelArr = {0, -3, -6, -9, -12, -15, -18, -21, -24, -27,
                  0, -3, -6, -9, -12, -15, -18, -21, -24, -27,
                  0, -3, -6, -9, -12, -15, -18, -21, -24, -27
                 }

    Public dwelArr = {0.001, 0.001, 0.001, 0.001, 0.001, 0.001, 0.001, 0.001, 0.001, 0.001,
               0.001, 0.001, 0.001, 0.001, 0.001, 0.001, 0.001, 0.001, 0.001, 0.001,
               0.001, 0.001, 0.001, 0.001, 0.001, 0.001, 0.001, 0.001, 0.001, 0.001
              }

    Public freqLevelTableData As DataTable
    Public freqencyLevel As rscmwgprf_frequency_level_settings
    Private instrument As rscmwgprf

    Private Sub measBtn_Click(sender As System.Object, e As System.EventArgs) Handles measBtn.Click
        Dim frequencies As Double() = New Double(29) {}
        Dim levels As Double() = New Double(29) {}
        Dim resultsRMS As Double() = New Double(29) {}
        Dim resultsMin As Double() = New Double(29) {}
        Dim resultsMax As Double() = New Double(29) {}

        Dim reliability As Integer
        Dim count As Integer

        'copy from DataTable
        For i As Integer = 0 To freqLevelTableData.Rows.Count - 1
            frequencies(i) = CDbl(freqLevelTableData.Rows(i)("frequency"))
            levels(i) = CDbl(freqLevelTableData.Rows(i)("level"))
        Next

        Try
            ' initialize connection to instrument
            instrument = New rscmwgprf("cmw", True, True)

            ' generator setup
            instrument.ConfigureGeneratorMode(1, rscmwgprfConstants.GenmodeCw)
            instrument.ConfigureGeneratorStandAloneScenario(1, rscmwgprfConstants.GeneratorConnRf1c, rscmwgprfConstants.GeneratorSalConvTx1)
            instrument.ConfigureGeneratorMode(1, rscmwgprfConstants.GenmodeList)
            instrument.ConfigureGeneratorListRange(1, 0, 29)
            instrument.ConfigureGeneratorList(1, 30, frequencies, levels, New Double(29) {}, dwelArr, _
             New UShort(29) {})
            instrument.ConfigureGeneratorState(1, True)

            ' analyzer setup
            instrument.ConfigureAnalyzerStandAloneScenario(1, rscmwgprfConstants.AnalyzerConnRf1c, rscmwgprfConstants.AnalyzerSalConvRx1)
            instrument.ConfigurePwrMeasListRange(1, True, 0, 29)
            instrument.ConfigurePwrMeasParameters(1, 0.0005, 0.001)
            instrument.ConfigurePwrMeasList(1, 30, freqArr, New Double(29) {})
            instrument.ConfigurePwrMeasStatistics(1, rscmwgprfConstants.RepetitionSingle, 20)
            instrument.ConfigurePwrMeasTrigger(1, "IF Power", rscmwgprfConstants.TrigslopeRising, -30.0, 0.00025, rscmwgprfConstants.TrigmodeOnce, _
             1.0)
            instrument.ConfigurePwrMeasTriggerGap(1, 0.01)

            ' init measurement
            instrument.PwrMeasInit(1)

            ' fetch results
            instrument.FetchPwrMeas(1, rscmwgprfConstants.ResultCurrent, rscmwgprfConstants.DetectorRms, 30, reliability, resultsRMS, _
             count)
            instrument.FetchPwrMeas(1, rscmwgprfConstants.ResultCurrent, rscmwgprfConstants.DetectorMin, 30, reliability, resultsMin, _
             count)
            instrument.FetchPwrMeas(1, rscmwgprfConstants.ResultCurrent, rscmwgprfConstants.DetectorMax, 30, reliability, resultsMax, _
             count)

            resultsTable.Rows.Add(resultsRMS.Length)
            For i As Integer = 0 To resultsRMS.Length - 1
                resultsTable.Rows(i).Cells("step").Value = i
                resultsTable.Rows(i).Cells("rms").Value = resultsRMS(i)
                resultsTable.Rows(i).Cells("min").Value = resultsMin(i)
                resultsTable.Rows(i).Cells("max").Value = resultsMax(i)
            Next
        Catch ex As System.Runtime.InteropServices.ExternalException
            Dim message As String
            message = "Instrument Status Error: " + ex.Message + Environment.NewLine
            message += "Instrument Error Code: " + ex.Message + ex.ErrorCode.ToString("X")
            MessageBox.Show(message)
        End Try
    End Sub

    Private Sub rscmwgprf_list_mode_example_Shown(sender As System.Object, e As System.EventArgs) Handles MyBase.Shown
        freqLevelTableData = New DataTable()
        Dim row As DataRow

        'init freq and level tabel

        Dim col As New DataColumn("frequency", System.Type.[GetType]("System.Double"))
        freqLevelTableData.Columns.Add(col)
        col = New DataColumn("level", System.Type.[GetType]("System.Double"))
        freqLevelTableData.Columns.Add(col)
        For i As Integer = 0 To freqArr.Length - 1
            row = freqLevelTableData.NewRow()
            row("frequency") = freqArr(i)
            row("level") = levelArr(i)
            freqLevelTableData.Rows.Add(row)
        Next

        ' create results table

        resultsTable.Columns.Add("step", "Step")
        resultsTable.Columns("step").ValueType = System.Type.[GetType]("System.Int32")
        resultsTable.Columns("step").Width = 40

        resultsTable.Columns.Add("rms", "RMS [dB]")
        resultsTable.Columns("rms").ValueType = System.Type.[GetType]("System.Double")

        resultsTable.Columns.Add("min", "Min [dB]")
        resultsTable.Columns("min").ValueType = System.Type.[GetType]("System.Double")

        resultsTable.Columns.Add("max", "Max [dB]")
        resultsTable.Columns("max").ValueType = System.Type.[GetType]("System.Double")
    End Sub

    Private Sub settingsBtn_Click(sender As System.Object, e As System.EventArgs) Handles settingsBtn.Click
        freqencyLevel = New rscmwgprf_frequency_level_settings(freqLevelTableData)
        freqencyLevel.Show()
    End Sub
End Class
