﻿Public Class rscmwgprf_frequency_level_settings

    Sub New(freqLevelTableData As DataTable)
        InitializeComponent()
        freqTableGrid.DataSource = freqLevelTableData

        freqTableGrid.Columns("frequency").HeaderText = "Frequency [Hz]"
        freqTableGrid.Columns("level").HeaderText = "Level [dB]"

        freqTableGrid.Columns("frequency").Width = 120
    End Sub

    Private Sub okBtn_Click(sender As System.Object, e As System.EventArgs) Handles okBtn.Click
        Me.Close()
    End Sub
End Class