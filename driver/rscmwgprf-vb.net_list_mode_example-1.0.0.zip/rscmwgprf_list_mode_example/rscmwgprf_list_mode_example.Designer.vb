﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class rscmwgprf_list_mode_example
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(rscmwgprf_list_mode_example))
        Me.ResourceDescriptor = New System.Windows.Forms.TextBox()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.settingsBtn = New System.Windows.Forms.Button()
        Me.ResetDevice = New System.Windows.Forms.CheckBox()
        Me.resultsTable = New System.Windows.Forms.DataGridView()
        Me.ResourceGB = New System.Windows.Forms.GroupBox()
        Me.IDQuery = New System.Windows.Forms.CheckBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.measBtn = New System.Windows.Forms.Button()
        CType(Me.resultsTable, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.ResourceGB.SuspendLayout()
        Me.SuspendLayout()
        '
        'ResourceDescriptor
        '
        Me.ResourceDescriptor.Location = New System.Drawing.Point(5, 31)
        Me.ResourceDescriptor.Name = "ResourceDescriptor"
        Me.ResourceDescriptor.Size = New System.Drawing.Size(180, 20)
        Me.ResourceDescriptor.TabIndex = 43
        Me.ResourceDescriptor.Text = "TCPIP::192.168.5.120::INST"
        '
        'Label2
        '
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(238, Byte))
        Me.Label2.ForeColor = System.Drawing.Color.SteelBlue
        Me.Label2.Location = New System.Drawing.Point(-2, -1)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(518, 48)
        Me.Label2.TabIndex = 120
        Me.Label2.Text = "Rohde && Schwarz CMW GPRF List Mode Example"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'settingsBtn
        '
        Me.settingsBtn.AllowDrop = True
        Me.settingsBtn.Location = New System.Drawing.Point(433, 548)
        Me.settingsBtn.Name = "settingsBtn"
        Me.settingsBtn.Size = New System.Drawing.Size(75, 23)
        Me.settingsBtn.TabIndex = 124
        Me.settingsBtn.Text = "Settings"
        Me.settingsBtn.UseVisualStyleBackColor = True
        '
        'ResetDevice
        '
        Me.ResetDevice.Checked = True
        Me.ResetDevice.CheckState = System.Windows.Forms.CheckState.Checked
        Me.ResetDevice.Location = New System.Drawing.Point(397, 32)
        Me.ResetDevice.Name = "ResetDevice"
        Me.ResetDevice.Size = New System.Drawing.Size(96, 18)
        Me.ResetDevice.TabIndex = 42
        Me.ResetDevice.Text = "Reset Device"
        '
        'resultsTable
        '
        Me.resultsTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.resultsTable.Location = New System.Drawing.Point(2, 125)
        Me.resultsTable.Name = "resultsTable"
        Me.resultsTable.Size = New System.Drawing.Size(517, 417)
        Me.resultsTable.TabIndex = 122
        '
        'ResourceGB
        '
        Me.ResourceGB.Controls.Add(Me.ResourceDescriptor)
        Me.ResourceGB.Controls.Add(Me.ResetDevice)
        Me.ResourceGB.Controls.Add(Me.IDQuery)
        Me.ResourceGB.Controls.Add(Me.Label1)
        Me.ResourceGB.Location = New System.Drawing.Point(2, 50)
        Me.ResourceGB.Name = "ResourceGB"
        Me.ResourceGB.Size = New System.Drawing.Size(518, 69)
        Me.ResourceGB.TabIndex = 121
        Me.ResourceGB.TabStop = False
        '
        'IDQuery
        '
        Me.IDQuery.Checked = True
        Me.IDQuery.CheckState = System.Windows.Forms.CheckState.Checked
        Me.IDQuery.Location = New System.Drawing.Point(297, 32)
        Me.IDQuery.Name = "IDQuery"
        Me.IDQuery.Size = New System.Drawing.Size(72, 18)
        Me.IDQuery.TabIndex = 41
        Me.IDQuery.Text = "ID Query"
        '
        'Label1
        '
        Me.Label1.Location = New System.Drawing.Point(6, 12)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(120, 16)
        Me.Label1.TabIndex = 40
        Me.Label1.Text = "Resource Descriptor"
        '
        'measBtn
        '
        Me.measBtn.AllowDrop = True
        Me.measBtn.Location = New System.Drawing.Point(352, 548)
        Me.measBtn.Name = "measBtn"
        Me.measBtn.Size = New System.Drawing.Size(75, 23)
        Me.measBtn.TabIndex = 123
        Me.measBtn.Text = "Measure"
        Me.measBtn.UseVisualStyleBackColor = True
        '
        'rscmwgprf_list_mode_example
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(521, 578)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.settingsBtn)
        Me.Controls.Add(Me.resultsTable)
        Me.Controls.Add(Me.ResourceGB)
        Me.Controls.Add(Me.measBtn)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "rscmwgprf_list_mode_example"
        Me.Text = "Rohde & Schwarz CMW GPRF List Mode Example"
        CType(Me.resultsTable, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResourceGB.ResumeLayout(False)
        Me.ResourceGB.PerformLayout()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ResourceDescriptor As System.Windows.Forms.TextBox
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Private WithEvents settingsBtn As System.Windows.Forms.Button
    Friend WithEvents ResetDevice As System.Windows.Forms.CheckBox
    Private WithEvents resultsTable As System.Windows.Forms.DataGridView
    Private WithEvents ResourceGB As System.Windows.Forms.GroupBox
    Friend WithEvents IDQuery As System.Windows.Forms.CheckBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Private WithEvents measBtn As System.Windows.Forms.Button

End Class
