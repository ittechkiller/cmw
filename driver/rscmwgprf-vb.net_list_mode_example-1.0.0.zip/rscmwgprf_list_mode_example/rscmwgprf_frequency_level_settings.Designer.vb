﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class rscmwgprf_frequency_level_settings
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(rscmwgprf_frequency_level_settings))
        Me.okBtn = New System.Windows.Forms.Button()
        Me.freqTableGrid = New System.Windows.Forms.DataGridView()
        CType(Me.freqTableGrid, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'okBtn
        '
        Me.okBtn.Location = New System.Drawing.Point(331, 376)
        Me.okBtn.Name = "okBtn"
        Me.okBtn.Size = New System.Drawing.Size(75, 23)
        Me.okBtn.TabIndex = 3
        Me.okBtn.Text = "OK"
        Me.okBtn.UseVisualStyleBackColor = True
        '
        'freqTableGrid
        '
        Me.freqTableGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.freqTableGrid.Location = New System.Drawing.Point(0, 0)
        Me.freqTableGrid.Name = "freqTableGrid"
        Me.freqTableGrid.Size = New System.Drawing.Size(418, 370)
        Me.freqTableGrid.TabIndex = 2
        '
        'frequency_level_settings
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(418, 406)
        Me.Controls.Add(Me.okBtn)
        Me.Controls.Add(Me.freqTableGrid)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Name = "frequency_level_settings"
        Me.Text = "Settings"
        CType(Me.freqTableGrid, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Private WithEvents okBtn As System.Windows.Forms.Button
    Private WithEvents freqTableGrid As System.Windows.Forms.DataGridView
End Class
