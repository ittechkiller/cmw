﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace rscmwgprf_list_mode_example
{
    public partial class frequencyLevelSettings : Form
    {
        public frequencyLevelSettings(DataTable data)
        {
            InitializeComponent();
            freqTableGrid.DataSource = data;

            freqTableGrid.Columns["frequency"].HeaderText = "Frequency [Hz]";
            freqTableGrid.Columns["level"].HeaderText = "Level [dB]";

            freqTableGrid.Columns["frequency"].Width = 120;            
        }

        private void frequency_level_settings_Load(object sender, EventArgs e)
        {                        
        }

        private void freqTable_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
