﻿namespace rscmwgprf_list_mode_example
{
    partial class rscmwgprf_list_mode_example
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(rscmwgprf_list_mode_example));
            this.Label2 = new System.Windows.Forms.Label();
            this.ResourceGB = new System.Windows.Forms.GroupBox();
            this.ResourceDescriptor = new System.Windows.Forms.TextBox();
            this.ResetDevice = new System.Windows.Forms.CheckBox();
            this.IDQuery = new System.Windows.Forms.CheckBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.resultsTable = new System.Windows.Forms.DataGridView();
            this.settingsBtn = new System.Windows.Forms.Button();
            this.measBtn = new System.Windows.Forms.Button();
            this.ResourceGB.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.resultsTable)).BeginInit();
            this.SuspendLayout();
            // 
            // Label2
            // 
            this.Label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Label2.ForeColor = System.Drawing.Color.SteelBlue;
            this.Label2.Location = new System.Drawing.Point(-4, 9);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(518, 48);
            this.Label2.TabIndex = 116;
            this.Label2.Text = "Rohde && Schwarz CMW GPRF List Mode Example";
            this.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // ResourceGB
            // 
            this.ResourceGB.Controls.Add(this.ResourceDescriptor);
            this.ResourceGB.Controls.Add(this.ResetDevice);
            this.ResourceGB.Controls.Add(this.IDQuery);
            this.ResourceGB.Controls.Add(this.Label1);
            this.ResourceGB.Location = new System.Drawing.Point(0, 60);
            this.ResourceGB.Name = "ResourceGB";
            this.ResourceGB.Size = new System.Drawing.Size(518, 69);
            this.ResourceGB.TabIndex = 117;
            this.ResourceGB.TabStop = false;
            // 
            // ResourceDescriptor
            // 
            this.ResourceDescriptor.Location = new System.Drawing.Point(7, 31);
            this.ResourceDescriptor.Name = "ResourceDescriptor";
            this.ResourceDescriptor.Size = new System.Drawing.Size(180, 20);
            this.ResourceDescriptor.TabIndex = 43;
            this.ResourceDescriptor.Text = "TCPIP::192.168.5.120::INST";
            // 
            // ResetDevice
            // 
            this.ResetDevice.Checked = true;
            this.ResetDevice.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ResetDevice.Location = new System.Drawing.Point(397, 32);
            this.ResetDevice.Name = "ResetDevice";
            this.ResetDevice.Size = new System.Drawing.Size(96, 18);
            this.ResetDevice.TabIndex = 42;
            this.ResetDevice.Text = "Reset Device";
            // 
            // IDQuery
            // 
            this.IDQuery.Checked = true;
            this.IDQuery.CheckState = System.Windows.Forms.CheckState.Checked;
            this.IDQuery.Location = new System.Drawing.Point(297, 32);
            this.IDQuery.Name = "IDQuery";
            this.IDQuery.Size = new System.Drawing.Size(72, 18);
            this.IDQuery.TabIndex = 41;
            this.IDQuery.Text = "ID Query";
            // 
            // Label1
            // 
            this.Label1.Location = new System.Drawing.Point(7, 12);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(120, 16);
            this.Label1.TabIndex = 40;
            this.Label1.Text = "Resource Descriptor";
            // 
            // resultsTable
            // 
            this.resultsTable.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.resultsTable.Location = new System.Drawing.Point(0, 135);
            this.resultsTable.Name = "resultsTable";
            this.resultsTable.ReadOnly = true;
            this.resultsTable.Size = new System.Drawing.Size(517, 417);
            this.resultsTable.TabIndex = 118;
            // 
            // settingsBtn
            // 
            this.settingsBtn.AllowDrop = true;
            this.settingsBtn.Location = new System.Drawing.Point(431, 560);
            this.settingsBtn.Name = "settingsBtn";
            this.settingsBtn.Size = new System.Drawing.Size(75, 23);
            this.settingsBtn.TabIndex = 119;
            this.settingsBtn.Text = "Settings";
            this.settingsBtn.UseVisualStyleBackColor = true;
            this.settingsBtn.Click += new System.EventHandler(this.settingsBtn_Click);
            // 
            // measBtn
            // 
            this.measBtn.AllowDrop = true;
            this.measBtn.Location = new System.Drawing.Point(350, 560);
            this.measBtn.Name = "measBtn";
            this.measBtn.Size = new System.Drawing.Size(75, 23);
            this.measBtn.TabIndex = 119;
            this.measBtn.Text = "Measure";
            this.measBtn.UseVisualStyleBackColor = true;
            this.measBtn.Click += new System.EventHandler(this.measBtn_Click);
            // 
            // rscmwgprf_list_mode_example
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(518, 593);
            this.Controls.Add(this.measBtn);
            this.Controls.Add(this.settingsBtn);
            this.Controls.Add(this.resultsTable);
            this.Controls.Add(this.ResourceGB);
            this.Controls.Add(this.Label2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "rscmwgprf_list_mode_example";
            this.Text = "Rohde & Schwarz CMW GPRF List Mode Example";
            this.ResourceGB.ResumeLayout(false);
            this.ResourceGB.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.resultsTable)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        internal System.Windows.Forms.Label Label2;
        private System.Windows.Forms.GroupBox ResourceGB;
        internal System.Windows.Forms.TextBox ResourceDescriptor;
        internal System.Windows.Forms.CheckBox ResetDevice;
        internal System.Windows.Forms.CheckBox IDQuery;
        internal System.Windows.Forms.Label Label1;
        private System.Windows.Forms.DataGridView resultsTable;
        private System.Windows.Forms.Button settingsBtn;
        private System.Windows.Forms.Button measBtn;
    }
}

