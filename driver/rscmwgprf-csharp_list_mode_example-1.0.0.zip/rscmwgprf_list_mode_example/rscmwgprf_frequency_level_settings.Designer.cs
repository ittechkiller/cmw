﻿namespace rscmwgprf_list_mode_example
{
    partial class frequencyLevelSettings
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frequencyLevelSettings));
            this.freqTableGrid = new System.Windows.Forms.DataGridView();
            this.okBtn = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.freqTableGrid)).BeginInit();
            this.SuspendLayout();
            // 
            // freqTableGrid
            // 
            this.freqTableGrid.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.freqTableGrid.Location = new System.Drawing.Point(0, 0);
            this.freqTableGrid.Name = "freqTableGrid";
            this.freqTableGrid.Size = new System.Drawing.Size(418, 370);
            this.freqTableGrid.TabIndex = 0;
            this.freqTableGrid.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.freqTable_CellContentClick);
            // 
            // okBtn
            // 
            this.okBtn.Location = new System.Drawing.Point(331, 376);
            this.okBtn.Name = "okBtn";
            this.okBtn.Size = new System.Drawing.Size(75, 23);
            this.okBtn.TabIndex = 1;
            this.okBtn.Text = "OK";
            this.okBtn.UseVisualStyleBackColor = true;
            this.okBtn.Click += new System.EventHandler(this.button1_Click);
            // 
            // frequencyLevelSettings
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(418, 411);
            this.Controls.Add(this.okBtn);
            this.Controls.Add(this.freqTableGrid);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "frequencyLevelSettings";
            this.Text = "List";
            this.Load += new System.EventHandler(this.frequency_level_settings_Load);
            ((System.ComponentModel.ISupportInitialize)(this.freqTableGrid)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView freqTableGrid;
        private System.Windows.Forms.Button okBtn;
    }
}