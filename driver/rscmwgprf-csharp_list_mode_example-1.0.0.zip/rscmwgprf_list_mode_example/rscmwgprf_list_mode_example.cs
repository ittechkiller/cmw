﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using InstrumentDrivers;

namespace rscmwgprf_list_mode_example
{      
    public partial class rscmwgprf_list_mode_example : Form
    {
        private frequencyLevelSettings freqencyLevel;
        private rscmwgprf instrument;

        /*Default values of frequency list [Hz]*/
        public double[] freqArr = {1e9, 1e9, 1e9, 1e9, 1e9, 1e9, 1e9, 1e9, 1e9, 1e9,
					              2e9, 2e9, 2e9, 2e9, 2e9, 2e9, 2e9, 2e9, 2e9, 2e9,
					              3e9, 3e9, 3e9, 3e9, 3e9, 3e9, 3e9, 3e9, 3e9, 3e9
					             };
        /*Default values of level(RMS) list [dBm]*/
        public double[] levelArr = {0, -3, -6, -9, -12, -15, -18, -21, -24, -27, 
					                 0, -3, -6, -9, -12, -15, -18, -21, -24, -27, 
					                 0, -3, -6, -9, -12, -15, -18, -21, -24, -27
					                };
        /*Default values for Dwel time*/
        public double[] dwelArr = {1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3,
					              1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3,
					              1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3
					             };

        public DataTable freqLevelTableData;

        public rscmwgprf_list_mode_example()
        {
        //GUI settings
            InitializeComponent();
            
            freqLevelTableData = new DataTable();            
            DataRow row;
            
            /*init and fill freq and level tabel*/
            DataColumn col = new DataColumn("frequency", System.Type.GetType("System.Double"));
            freqLevelTableData.Columns.Add(col);
            col = new DataColumn("level", System.Type.GetType("System.Double"));
            freqLevelTableData.Columns.Add(col);
            for (int i=0; i<freqArr.Length; i++)
            {
                row = freqLevelTableData.NewRow();
                row["frequency"] = freqArr[i];
                row["level"] = levelArr[i];
                freqLevelTableData.Rows.Add(row);
            }            
                      
            /* init results table*/
            resultsTable.Columns.Add("step", "Step");
            resultsTable.Columns["step"].ValueType = System.Type.GetType("System.Int32");
            resultsTable.Columns["step"].Width = 40;

            resultsTable.Columns.Add("rms", "RMS [dB]");
            resultsTable.Columns["rms"].ValueType = System.Type.GetType("System.Double");
            
            resultsTable.Columns.Add("min", "Min [dB]");
            resultsTable.Columns["min"].ValueType = System.Type.GetType("System.Double");
            
            resultsTable.Columns.Add("max", "Max [dB]");
            resultsTable.Columns["max"].ValueType = System.Type.GetType("System.Double");            
        }

        private void settingsBtn_Click(object sender, EventArgs e)
        {
            freqencyLevel = new frequencyLevelSettings(freqLevelTableData);
            freqencyLevel.Show();
        }

        private void measBtn_Click(object sender, EventArgs e)
        {
            try
            {                
                //results array
                double[] resultsRMS = new double[freqArr.Length];
                double[] resultsMin = new double[freqArr.Length];
                double[] resultsMax = new double[freqArr.Length];
                
                int reliability;
                int count;

                //copy from DataTable
                for (int i = 0; i < freqArr.Length; i++)
                {
                    freqArr[i] = (double)freqLevelTableData.Rows[i]["frequency"];
                    levelArr[i] = (double)freqLevelTableData.Rows[i]["level"];
                }

                // initialize connection to instrument
                instrument = new rscmwgprf(ResourceDescriptor.Text, true, true);

                // generator setup
                instrument.ConfigureGeneratorMode(1, rscmwgprfConstants.GenmodeCw);
                instrument.ConfigureGeneratorStandAloneScenario(1, rscmwgprfConstants.GeneratorConnRf1c, rscmwgprfConstants.GeneratorSalConvTx1);
                instrument.ConfigureGeneratorMode(1, rscmwgprfConstants.GenmodeList);
                instrument.ConfigureGeneratorListRange(1, 0, 29);
                instrument.ConfigureGeneratorList(1, freqArr.Length, freqArr, levelArr, new double[freqArr.Length], dwelArr, new ushort[freqArr.Length]);
                instrument.ConfigureGeneratorState(1, true);

                // analyzer setup
                instrument.ConfigureAnalyzerStandAloneScenario(1, rscmwgprfConstants.AnalyzerConnRf1c, rscmwgprfConstants.AnalyzerSalConvRx1);
                instrument.ConfigurePwrMeasListRange(1, true, 0, freqArr.Length - 1);
                instrument.ConfigurePwrMeasParameters(1, 0.5e-3, 1e-3);
                instrument.ConfigurePwrMeasList(1, freqArr.Length, freqArr, new double[freqArr.Length]);
                instrument.ConfigurePwrMeasStatistics(1, rscmwgprfConstants.RepetitionSingle, 20);
                instrument.ConfigurePwrMeasTrigger(1, "IF Power", rscmwgprfConstants.TrigslopeRising, -30.0, 0.25E-3, rscmwgprfConstants.TrigmodeOnce, 1.0);
                instrument.ConfigurePwrMeasTriggerGap(1, 1.0e-2);

                // init measurement
                instrument.PwrMeasInit(1);

                // fetch results
                instrument.FetchPwrMeas(1, rscmwgprfConstants.ResultCurrent, rscmwgprfConstants.DetectorRms, freqArr.Length, out reliability, resultsRMS, out count);
                instrument.FetchPwrMeas(1, rscmwgprfConstants.ResultCurrent, rscmwgprfConstants.DetectorMin, freqArr.Length, out reliability, resultsMin, out count);
                instrument.FetchPwrMeas(1, rscmwgprfConstants.ResultCurrent, rscmwgprfConstants.DetectorMax, freqArr.Length, out reliability, resultsMax, out count);

                resultsTable.Rows.Add(resultsRMS.Length);
                for (int i = 0; i < resultsRMS.Length; i++)
                {
                    resultsTable.Rows[i].Cells["step"].Value = i;
                    resultsTable.Rows[i].Cells["rms"].Value = resultsRMS[i];
                    resultsTable.Rows[i].Cells["min"].Value = resultsMin[i];
                    resultsTable.Rows[i].Cells["max"].Value = resultsMax[i];
                }
            }
            catch (System.Runtime.InteropServices.ExternalException ex)
            {
                String message;
                message = "Instrument Status Error: " + ex.Message + Environment.NewLine;
                message += "Instrument Error Code: " + ex.ErrorCode.ToString("X");
                MessageBox.Show(message);
            }
        }
    }
}
