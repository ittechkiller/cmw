/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/* Copyright (c) National Instruments 2010. All Rights Reserved.          */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  PANEL                            1
#define  PANEL_INSTR_DESC                 2
#define  PANEL_EXIT                       3       /* callback function: exitApp */
#define  PANEL_IDQUERY                    4
#define  PANEL_START                      5       /* callback function: startMeas */
#define  PANEL_RESET                      6
#define  PANEL_POW_TABLE                  7
#define  PANEL_DECORATION                 8
#define  PANEL_DECORATION_2               9
#define  PANEL_SPLITTER                   10
#define  PANEL_CONF                       11


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */

int  CVICALLBACK exitApp(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK startMeas(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif
