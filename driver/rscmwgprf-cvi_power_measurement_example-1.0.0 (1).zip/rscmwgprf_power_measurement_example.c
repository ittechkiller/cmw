#include <cvirte.h>	
#include <userint.h>
#include "rscmwgprf_power_measurement_example.h"
#include "rscmwgprf.h"

#define STRING_LENGTH 512

/* Useful macros */
#define CHECKERR(fCal) \
    if (status = checkError((fCal)), status < VI_SUCCESS) \
        return status; else

#define CHECKERR_GO(fCal) \
    if (status = (fCal), status < VI_SUCCESS) \
        return status; else

/* Utility functions declarations */
int configureGenerator(ViReal64 freq);
int configureMeasurement(ViReal64 freq, ViReal64 nomPwr); 
int measurePower(ViReal64 *rms, ViReal64 *min, ViReal64 *max);

ViStatus checkError(ViStatus status);
void EnableButtons(ViBoolean enable); 
void cleanup (ViBoolean deviceClear);


static ViSession instrSession;
static int panelHandle;


int main (int argc, char *argv[])
{
	if (InitCVIRTE (0, argv, 0) == 0)
		return -1;	/* out of memory */
	if ((panelHandle = LoadPanel (0, "rscmwgprf_power_measurement_example.uir", PANEL)) < 0)
		return -1;
	
	DisplayPanel (panelHandle);
	RunUserInterface ();
	DiscardPanel (panelHandle);
	return 0;
}


/*===========================================================================*/
/* Function: exitApp                                                         */
/* Purpose:  This is a callback function of Exit button. It closes the       */
/*           session and exits the example.                                  */
/*===========================================================================*/
int CVICALLBACK exitApp (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			if(instrSession) cleanup(VI_TRUE);
			QuitUserInterface (0);
			break;
	}
	return 0;
}


/*===========================================================================*/
/* Function: Start Button Callback
/* Purpose:  Configures the instrument and initiates the measurement
/*===========================================================================*/
int CVICALLBACK startMeas (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	char instrDesc[STRING_LENGTH];
	char strBuf[20];
	ViStatus status = VI_SUCCESS;
	
	ViReal64 rms = 0;
	ViReal64 min = 0;
	ViReal64 max = 0;
	ViReal64 freq= 0;
	ViReal64 level= 0;
	
    ViInt32 id 	 = 0;
    ViInt32 reset= 0;
	
	switch (event)
	{
		case EVENT_COMMIT:
			{
				/* block mouse events */
				SetWaitCursor (1);			
				
				/* disable buttons for configuration */
				EnableButtons(VI_FALSE);
				
				/*get value from controls*/
				GetCtrlVal (panel, PANEL_INSTR_DESC, instrDesc);
				GetCtrlVal (panel, PANEL_IDQUERY, &id);
				GetCtrlVal (panel, PANEL_RESET, &reset);
				GetTableCellVal (panel, PANEL_CONF, MakePoint(2,1), &freq);
				freq *= 1e6;
				GetTableCellVal (panel, PANEL_CONF, MakePoint(3,1), strBuf);
				GetTableCellVal (panel, PANEL_CONF, MakePoint(2,2), &level);

				CHECKERR(rscmwgprf_init (instrDesc, VI_TRUE, VI_TRUE, &instrSession));
				
				CHECKERR(configureGenerator(freq));
				CHECKERR(configureMeasurement(freq, level));
				
				CHECKERR(measurePower(&rms, &min, &max));
				
				/*put result to controls*/
				sprintf(strBuf, "%.3f dBm", rms);
				SetTableCellVal (panel, PANEL_POW_TABLE, MakePoint(2, 1), strBuf);
				sprintf(strBuf, "%.3f dBm", min);
				SetTableCellVal (panel, PANEL_POW_TABLE, MakePoint(2, 2), strBuf);
				sprintf(strBuf, "%.3f dBm", max);
				SetTableCellVal (panel, PANEL_POW_TABLE, MakePoint(2, 3), strBuf);
				
				/* close session */
        		cleanup(VI_FALSE);
			}
			break;
	}
	return 0;
}

/*===========================================================================*/
/* Function: configureGenerator
/* Purpose:  Configures the generator
/*===========================================================================*/
int configureGenerator(ViReal64 freq) 
{
	ViStatus status = VI_SUCCESS;
	

	CHECKERR_GO(rscmwgprf_ConfigureGeneratorMode (instrSession, 1, RSCMWGPRF_VAL_GENMODE_CW));
	CHECKERR_GO(rscmwgprf_ConfigureGeneratorStandAloneScenario (instrSession, 1, RSCMWGPRF_VAL_ANALYZER_CONN_RF1C, RSCMWGPRF_VAL_ANALYZER_SAL_CONV_RX1));
	CHECKERR_GO(rscmwgprf_ConfigureGeneratorFrequencyLevel (instrSession, 1, freq, -10.0));
	CHECKERR_GO(rscmwgprf_ConfigureGeneratorState (instrSession, 1, VI_TRUE));
	
	return status;
}


/*===========================================================================*/
/* Function: configureMeasurement
/* Purpose:  Configures the measurement
/*===========================================================================*/
int configureMeasurement(ViReal64 freq, ViReal64 nomPwr)
{
  	ViStatus status = VI_SUCCESS;
	
	CHECKERR_GO(rscmwgprf_ConfigureAnalyzerStandAloneScenario (instrSession, 1, RSCMWGPRF_VAL_ANALYZER_CONN_RF1C, RSCMWGPRF_VAL_ANALYZER_SAL_CONV_RX1));
	CHECKERR_GO(rscmwgprf_ConfigureAnalyzer (instrSession, 1, nomPwr, 0.0, freq));
	CHECKERR_GO(rscmwgprf_ConfigurePwrMeasStatistics (instrSession, 1, RSCMWGPRF_VAL_REPETITION_SINGLE, 20));
	CHECKERR_GO(rscmwgprf_ConfigurePwrMeasTrigger (instrSession, 1, "Free Run", RSCMWGPRF_VAL_TRIGSLOPE_RISING,
		-30.0, 0.1E-3, RSCMWGPRF_VAL_TRIGMODE_ONCE, 1.0));
	
	return status;  
}				  


/*===========================================================================*/
/* Function: measurePower
/* Purpose:  Initiates the measurement
/*===========================================================================*/
int measurePower(ViReal64 *rms, ViReal64 *min, ViReal64 *max)
{
	ViStatus status = VI_SUCCESS;
	ViInt32 count, rel; 
	
	CHECKERR_GO(rscmwgprf_PwrMeasInit (instrSession, 1));

	CHECKERR_GO(rscmwgprf_FetchPwrMeas (instrSession, 1, RSCMWGPRF_VAL_RESULT_CURRENT,
		RSCMWGPRF_VAL_DETECTOR_RMS, 1, &rel, rms, &count)); 
	CHECKERR_GO(rscmwgprf_FetchPwrMeas (instrSession, 1, RSCMWGPRF_VAL_RESULT_CURRENT,
		RSCMWGPRF_VAL_DETECTOR_MIN, 1, &rel, min, &count)); 
	CHECKERR_GO(rscmwgprf_FetchPwrMeas (instrSession, 1, RSCMWGPRF_VAL_RESULT_CURRENT,
		RSCMWGPRF_VAL_DETECTOR_MAX, 1, &rel, max, &count)); 
	
	return status;
}

/*===========================================================================*/
/* Function: checkError
/* Purpose:  If passed status indicates an failure, the error message will
/*           be displayed.
/*===========================================================================*/
ViStatus checkError (ViStatus status)
{
    ViChar  error_message [STRING_LENGTH];
    ViChar  error_buffer  [STRING_LENGTH*2];
    ViChar* p2buf;
    ViInt32 error;
    
    if (status < VI_SUCCESS)
    {
        /* Converts a status code returned by an instrument driver function into a user-readable string */
        rscmwgprf_error_message (instrSession, status, error_message);
        p2buf = error_buffer + sprintf (error_buffer, "Primary Error: 0x%08X, %s\n", status, error_message);
        
        
        /* This function reads an error code and a message from the instrument's error queue */
        rscmwgprf_error_query (instrSession, &error, error_message);
        
        SetWaitCursor (0);
        if (error != VI_SUCCESS)
        {
            sprintf (p2buf, "Secondary Error: 0x%08X, %s\n", error, error_message);
        }
        MessagePopup ("Error", error_buffer);
        
        /* close session */
        cleanup(VI_TRUE);
        
        /* enable buttons for configuration */
        EnableButtons(VI_TRUE);
    }
    return status;
}


/*===========================================================================*/
/* Function: EnableButtons
/* Purpose:  This function dis-/enables GUI while measuring/configuration.
/*===========================================================================*/
void EnableButtons(ViBoolean enable)
{
    SetCtrlAttribute (panelHandle, PANEL_START, ATTR_DIMMED,!enable);
	SetCtrlAttribute (panelHandle, PANEL_INSTR_DESC, ATTR_DIMMED,!enable);
}


/*===========================================================================*/
/* Function: Cleanup
/* Purpose:  Closes the VISA session to the instrument and in case of error
/*           queries the error and shows the dialog box with the passed error
/*           message. In case Device Clear is requested, it is necessary to 
/*           set the argument deviceClear to VI_TRUE.
/*===========================================================================*/
void cleanup (ViBoolean deviceClear)
{

    /* Device Clear is a low-level command and should be used in case the
     * instrument is waiting for Operation Complete to cancel the wait.
     * It is useful for instance in case of incorrect external trigger
     * when the instrument does not respond to any other command because of
     * waiting for trigger.
     */
    if (deviceClear)
    {
        viClear (instrSession);
        viPrintf (instrSession, "*CLS\n");
    }
    
    /* close instrument session */
    rscmwgprf_close (instrSession);
    instrSession = VI_NULL;
    
    /* enable GUI */
    EnableButtons (1);
    /* enable mouse events*/
    SetWaitCursor (0);
    
}
