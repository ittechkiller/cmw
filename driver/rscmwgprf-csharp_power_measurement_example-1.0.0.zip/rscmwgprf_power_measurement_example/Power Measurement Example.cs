﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Windows.Forms;
using InstrumentDrivers;


namespace rscmwgprf_power_measurement_example
{
    public partial class Form1 : Form
    {
        private rscmwgprf instrument;

        public Form1()
        {
            InitializeComponent();
        }

           
        private void measBtn_Click(object sender, EventArgs e)
        {
            double frequency = Convert.ToDouble(frequencyTB.Text);
            double level = Convert.ToDouble(levelTB.Text);
            double[] result = new double[1];
            int rel, count;

            try
            {
                instrument = new rscmwgprf(ResourceDescriptor.Text, true, true);

                // generator setup
                instrument.ConfigureGeneratorMode(1, rscmwgprfConstants.GenmodeCw);
                instrument.ConfigureGeneratorStandAloneScenario(1, rscmwgprfConstants.GeneratorConnRf1c, rscmwgprfConstants.GeneratorSalConvTx1);
                instrument.ConfigureGeneratorFrequencyLevel(1, frequency, level);

                // detector setup
                instrument.ConfigureAnalyzerStandAloneScenario(1, rscmwgprfConstants.AnalyzerConnRf1c, rscmwgprfConstants.AnalyzerSalConvRx1);
                instrument.ConfigureAnalyzer(1, level, 0.0, frequency);

                // measurement setup
                instrument.ConfigurePwrMeasStatistics(1, rscmwgprfConstants.RepetitionSingle, 20);
                instrument.ConfigurePwrMeasTrigger(1, "Free Run", rscmwgprfConstants.TriggerCont, -30.0, 0.1E-3, rscmwgprfConstants.TrigmodeOnce, 1.0);

                instrument.ConfigureGeneratorState(1, true);

                // init measure
                instrument.PwrMeasInit(1);

                // fetch results
                instrument.FetchPwrMeas(1, rscmwgprfConstants.ResultCurrent, rscmwgprfConstants.DetectorRms, 1, out rel, result, out count);
                powerRMSTB.Text = result[0].ToString();

                instrument.FetchPwrMeas(1, rscmwgprfConstants.ResultCurrent, rscmwgprfConstants.DetectorMin, 1, out rel, result, out count);
                powerMinTB.Text = result[0].ToString();

                instrument.FetchPwrMeas(1, rscmwgprfConstants.ResultCurrent, rscmwgprfConstants.DetectorMax, 1, out rel, result, out count);
                powerMaxTB.Text = result[0].ToString();
            }
            catch (System.Runtime.InteropServices.ExternalException ex)
            {
                String message;
                message = "Instrument Status Error: " + ex.Message + Environment.NewLine;
                message += "Instrument Error Code: " + ex.ErrorCode.ToString("X");
                MessageBox.Show(message);                
            }            

        }
     

    }
}
