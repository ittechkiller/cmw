﻿namespace rscmwgprf_power_measurement_example
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form1));
            this.measBtn = new System.Windows.Forms.Button();
            this.ResourceGB = new System.Windows.Forms.GroupBox();
            this.ResourceDescriptor = new System.Windows.Forms.TextBox();
            this.ResetDevice = new System.Windows.Forms.CheckBox();
            this.IDQuery = new System.Windows.Forms.CheckBox();
            this.Label1 = new System.Windows.Forms.Label();
            this.Label2 = new System.Windows.Forms.Label();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.levelTB = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.frequencyTB = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.groupBox2 = new System.Windows.Forms.GroupBox();
            this.powerMaxTB = new System.Windows.Forms.TextBox();
            this.label7 = new System.Windows.Forms.Label();
            this.powerMinTB = new System.Windows.Forms.TextBox();
            this.label5 = new System.Windows.Forms.Label();
            this.powerRMSTB = new System.Windows.Forms.TextBox();
            this.label6 = new System.Windows.Forms.Label();
            this.ResourceGB.SuspendLayout();
            this.groupBox1.SuspendLayout();
            this.groupBox2.SuspendLayout();
            this.SuspendLayout();
            // 
            // measBtn
            // 
            this.measBtn.AllowDrop = true;
            this.measBtn.Location = new System.Drawing.Point(442, 349);
            this.measBtn.Name = "measBtn";
            this.measBtn.Size = new System.Drawing.Size(75, 23);
            this.measBtn.TabIndex = 122;
            this.measBtn.Text = "Measure";
            this.measBtn.UseVisualStyleBackColor = true;
            this.measBtn.Click += new System.EventHandler(this.measBtn_Click);
            // 
            // ResourceGB
            // 
            this.ResourceGB.Controls.Add(this.ResourceDescriptor);
            this.ResourceGB.Controls.Add(this.ResetDevice);
            this.ResourceGB.Controls.Add(this.IDQuery);
            this.ResourceGB.Controls.Add(this.Label1);
            this.ResourceGB.Location = new System.Drawing.Point(3, 60);
            this.ResourceGB.Name = "ResourceGB";
            this.ResourceGB.Size = new System.Drawing.Size(518, 69);
            this.ResourceGB.TabIndex = 121;
            this.ResourceGB.TabStop = false;
            // 
            // ResourceDescriptor
            // 
            this.ResourceDescriptor.Location = new System.Drawing.Point(5, 31);
            this.ResourceDescriptor.Name = "ResourceDescriptor";
            this.ResourceDescriptor.Size = new System.Drawing.Size(180, 20);
            this.ResourceDescriptor.TabIndex = 43;
            this.ResourceDescriptor.Text = "TCPIP::192.168.5.120::INST";
            // 
            // ResetDevice
            // 
            this.ResetDevice.Checked = true;
            this.ResetDevice.CheckState = System.Windows.Forms.CheckState.Checked;
            this.ResetDevice.Location = new System.Drawing.Point(397, 32);
            this.ResetDevice.Name = "ResetDevice";
            this.ResetDevice.Size = new System.Drawing.Size(96, 18);
            this.ResetDevice.TabIndex = 42;
            this.ResetDevice.Text = "Reset Device";
            // 
            // IDQuery
            // 
            this.IDQuery.Checked = true;
            this.IDQuery.CheckState = System.Windows.Forms.CheckState.Checked;
            this.IDQuery.Location = new System.Drawing.Point(297, 32);
            this.IDQuery.Name = "IDQuery";
            this.IDQuery.Size = new System.Drawing.Size(72, 18);
            this.IDQuery.TabIndex = 41;
            this.IDQuery.Text = "ID Query";
            // 
            // Label1
            // 
            this.Label1.Location = new System.Drawing.Point(6, 12);
            this.Label1.Name = "Label1";
            this.Label1.Size = new System.Drawing.Size(120, 16);
            this.Label1.TabIndex = 40;
            this.Label1.Text = "Resource Descriptor";
            // 
            // Label2
            // 
            this.Label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(238)));
            this.Label2.ForeColor = System.Drawing.Color.SteelBlue;
            this.Label2.Location = new System.Drawing.Point(-1, 9);
            this.Label2.Name = "Label2";
            this.Label2.Size = new System.Drawing.Size(518, 48);
            this.Label2.TabIndex = 120;
            this.Label2.Text = "Rohde && Schwarz CMW GPRF Power Measurement Example";
            this.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // groupBox1
            // 
            this.groupBox1.Controls.Add(this.levelTB);
            this.groupBox1.Controls.Add(this.label4);
            this.groupBox1.Controls.Add(this.frequencyTB);
            this.groupBox1.Controls.Add(this.label3);
            this.groupBox1.Location = new System.Drawing.Point(6, 149);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Size = new System.Drawing.Size(514, 76);
            this.groupBox1.TabIndex = 124;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Generator Settings";
            // 
            // levelTB
            // 
            this.levelTB.Location = new System.Drawing.Point(390, 41);
            this.levelTB.Name = "levelTB";
            this.levelTB.Size = new System.Drawing.Size(100, 20);
            this.levelTB.TabIndex = 0;
            this.levelTB.Text = "-10.0";
            // 
            // label4
            // 
            this.label4.Location = new System.Drawing.Point(387, 22);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(120, 16);
            this.label4.TabIndex = 40;
            this.label4.Text = "Level [dBm]";
            // 
            // frequencyTB
            // 
            this.frequencyTB.Location = new System.Drawing.Point(6, 41);
            this.frequencyTB.Name = "frequencyTB";
            this.frequencyTB.Size = new System.Drawing.Size(176, 20);
            this.frequencyTB.TabIndex = 0;
            this.frequencyTB.Text = "1000 000 000";
            // 
            // label3
            // 
            this.label3.Location = new System.Drawing.Point(3, 22);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(120, 16);
            this.label3.TabIndex = 40;
            this.label3.Text = "Frequency [Hz]";
            // 
            // groupBox2
            // 
            this.groupBox2.Controls.Add(this.powerMaxTB);
            this.groupBox2.Controls.Add(this.label7);
            this.groupBox2.Controls.Add(this.powerMinTB);
            this.groupBox2.Controls.Add(this.label5);
            this.groupBox2.Controls.Add(this.powerRMSTB);
            this.groupBox2.Controls.Add(this.label6);
            this.groupBox2.Location = new System.Drawing.Point(3, 257);
            this.groupBox2.Name = "groupBox2";
            this.groupBox2.Size = new System.Drawing.Size(514, 86);
            this.groupBox2.TabIndex = 125;
            this.groupBox2.TabStop = false;
            this.groupBox2.Text = "Measurement Results";
            // 
            // powerMaxTB
            // 
            this.powerMaxTB.Enabled = false;
            this.powerMaxTB.Location = new System.Drawing.Point(393, 41);
            this.powerMaxTB.Name = "powerMaxTB";
            this.powerMaxTB.Size = new System.Drawing.Size(100, 20);
            this.powerMaxTB.TabIndex = 0;
            // 
            // label7
            // 
            this.label7.Location = new System.Drawing.Point(390, 22);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(120, 16);
            this.label7.TabIndex = 40;
            this.label7.Text = "Power Max [dBm]";
            // 
            // powerMinTB
            // 
            this.powerMinTB.Enabled = false;
            this.powerMinTB.Location = new System.Drawing.Point(197, 41);
            this.powerMinTB.Name = "powerMinTB";
            this.powerMinTB.Size = new System.Drawing.Size(100, 20);
            this.powerMinTB.TabIndex = 0;
            // 
            // label5
            // 
            this.label5.Location = new System.Drawing.Point(194, 22);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(120, 16);
            this.label5.TabIndex = 40;
            this.label5.Text = "Power Min [dBm]";
            // 
            // powerRMSTB
            // 
            this.powerRMSTB.Enabled = false;
            this.powerRMSTB.Location = new System.Drawing.Point(9, 41);
            this.powerRMSTB.Name = "powerRMSTB";
            this.powerRMSTB.Size = new System.Drawing.Size(100, 20);
            this.powerRMSTB.TabIndex = 0;
            // 
            // label6
            // 
            this.label6.Location = new System.Drawing.Point(6, 22);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(120, 16);
            this.label6.TabIndex = 40;
            this.label6.Text = "Power RMS [dBm]";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(524, 380);
            this.Controls.Add(this.groupBox2);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.measBtn);
            this.Controls.Add(this.ResourceGB);
            this.Controls.Add(this.Label2);
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Form1";
            this.Text = "Rohde & Schwarz CMW GPRF Power Measurement Example";
            this.ResourceGB.ResumeLayout(false);
            this.ResourceGB.PerformLayout();
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            this.groupBox2.ResumeLayout(false);
            this.groupBox2.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button measBtn;
        private System.Windows.Forms.GroupBox ResourceGB;
        internal System.Windows.Forms.TextBox ResourceDescriptor;
        internal System.Windows.Forms.CheckBox ResetDevice;
        internal System.Windows.Forms.CheckBox IDQuery;
        internal System.Windows.Forms.Label Label1;
        internal System.Windows.Forms.Label Label2;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.TextBox levelTB;
        internal System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox frequencyTB;
        internal System.Windows.Forms.Label label3;
        private System.Windows.Forms.GroupBox groupBox2;
        private System.Windows.Forms.TextBox powerRMSTB;
        internal System.Windows.Forms.Label label6;
        private System.Windows.Forms.TextBox powerMaxTB;
        internal System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox powerMinTB;
        internal System.Windows.Forms.Label label5;
    }
}

