#include <cvirte.h>		
#include <userint.h>
#include "rscmwgprf.h"
#include "rscmwgprf_list_mode_example.h"
#include "toolbox.h" 

#define STRING_LENGTH 512

/* Useful macros */
#define CHECKERR(fCal) \
    if (status = checkError((fCal)), status < VI_SUCCESS) \
        return status; else

#define LIST_START 0
#define LIST_STOP 29
#define LIST_LEN  30

/* Utility functions declarations */
int configureGenerator(void);
int configureMeasurement(void);
int measurePower(void);

ViStatus checkError(ViStatus status);
void EnableButtons(ViBoolean enable); 
void cleanup (ViBoolean deviceClear);
void loadDefaults(void);

/*Default values of frequency list [Hz]*/
ViReal64 freqArr[] = {1e9, 1e9, 1e9, 1e9, 1e9, 1e9, 1e9, 1e9, 1e9, 1e9,
					  2e9, 2e9, 2e9, 2e9, 2e9, 2e9, 2e9, 2e9, 2e9, 2e9,
					  3e9, 3e9, 3e9, 3e9, 3e9, 3e9, 3e9, 3e9, 3e9, 3e9
					 };
/*Default values of level(RMS) list [dBm]*/
ViReal64 levArr[] = {0, -3, -6, -9, -12, -15, -18, -21, -24, -27, 
					 0, -3, -6, -9, -12, -15, -18, -21, -24, -27, 
					 0, -3, -6, -9, -12, -15, -18, -21, -24, -27
					};
/*Default values of Dwell time list [dBm]*/  
ViReal64 dwelArr[] = {1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3,
					  1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3,
					  1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3
					 };

ViReal64 zeroArr[] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
					  0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
					  0, 0, 0, 0, 0, 0, 0, 0, 0, 0
					 };
ViBoolean falseArr[] = {VI_FALSE, VI_FALSE, VI_FALSE, VI_FALSE, VI_FALSE, VI_FALSE, VI_FALSE, VI_FALSE, VI_FALSE, VI_FALSE,
					  VI_FALSE, VI_FALSE, VI_FALSE, VI_FALSE, VI_FALSE, VI_FALSE, VI_FALSE, VI_FALSE, VI_FALSE, VI_FALSE,
					  VI_FALSE, VI_FALSE, VI_FALSE, VI_FALSE, VI_FALSE, VI_FALSE, VI_FALSE, VI_FALSE, VI_FALSE, VI_FALSE
					 };

static ViSession instrSession = VI_NULL;
static int panelHandle;
static int panelSettings;
static int plotHandle;
static ViReal64 rmsArr[LIST_LEN];
static ViReal64 minArr[LIST_LEN];
static ViReal64 maxArr[LIST_LEN];

int main (int argc, char *argv[])
{
	if (InitCVIRTE (0, argv, 0) == 0)
		return -1;	/* out of memory */
	if ((panelHandle = LoadPanel (0, "rscmwgprf_list_mode_example.uir", MAIN)) < 0)
		return -1;
	
	if ((panelSettings = LoadPanel (0, "rscmwgprf_list_mode_example.uir", LIST)) < 0)
		return -1;
	
	loadDefaults();
	DisplayPanel (panelHandle);
	RunUserInterface ();
	DiscardPanel (panelHandle);
	return 0;
}


/*===========================================================================*/
/* Function: powSelect
/* Purpose:  For selected power, displays data in Reasults@Marker table
/*===========================================================================*/
int CVICALLBACK powSelelect (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	int i=0;
	char strBuf[20];
	
	switch (event)
	{
		case EVENT_COMMIT:
			{
				GetGraphCursorIndex (panelHandle, MAIN_POW_GRAPH, 1, &plotHandle, &i);
				if(i >= 0 )
				{
					sprintf(strBuf, "%.3lG dBm", rmsArr[i]);
					SetTableCellVal (panelHandle, MAIN_POW_TABLE, MakePoint(2, 1), strBuf);
					sprintf(strBuf, "%.3lG dBm", minArr[i]);
					SetTableCellVal (panelHandle, MAIN_POW_TABLE, MakePoint(2, 2), strBuf);
					sprintf(strBuf, "%.3lG dBm", maxArr[i]);
					SetTableCellVal (panelHandle, MAIN_POW_TABLE, MakePoint(2, 3), strBuf);
				}	
			}
			break;
	}
	return 0;
}


/*===========================================================================*/
/* Function: exitApp                                                         */
/* Purpose:  This is a callback function of Exit button. It closes the       */
/*           session and exits the example.                                  */
/*===========================================================================*/
int CVICALLBACK exitApp (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			if(instrSession) cleanup(VI_TRUE); 
			QuitUserInterface (0);
			break;
	}
	return 0;
}


/*===========================================================================*/
/* Function: Start Button Callback
/* Purpose:  Configures the instrument and initiates the measurement
/*===========================================================================*/
int CVICALLBACK startMeas (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	ViStatus status = VI_SUCCESS;
	char instrDesc[STRING_LENGTH];	
	int id = 0;
	int reset = 0;
	
	switch (event)
	{
		case EVENT_COMMIT:
			{
				/* block mouse events */
				SetWaitCursor (1);			
				
				/* disable buttons for configuration */
				EnableButtons(VI_FALSE);				
				
				GetCtrlVal (panel, MAIN_INSTR_DESC, instrDesc);
				GetCtrlVal (panel, MAIN_IDQUERY, &id);
				GetCtrlVal (panel, MAIN_RESET, &reset);
				
				/*create instrument session*/
				CHECKERR(rscmwgprf_init (instrDesc, id, reset, &instrSession));
				
				CHECKERR(configureGenerator());
				CHECKERR(configureMeasurement());
				
				/*turn generator on*/
				CHECKERR(rscmwgprf_ConfigureGeneratorState (instrSession, 1, VI_TRUE));
				
				CHECKERR(measurePower());
				
				/*Delete old plot*/
				DeleteGraphPlot (panel, MAIN_POW_GRAPH, -1, 1);
				/*Display data in graph*/
				plotHandle = PlotY (panel, MAIN_POW_GRAPH, levArr, LIST_LEN, VAL_DOUBLE,
								VAL_VERTICAL_BAR, VAL_EMPTY_SQUARE, VAL_SOLID, 1, VAL_BLUE);
				
				/* close session */
        		cleanup(VI_FALSE);
			}
			break;
	}
	return 0;
}


/*===========================================================================*/
/* Function: setupCall Callback
/* Purpose:  Displays panel with configuration
/*===========================================================================*/
int CVICALLBACK setupCall (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			DisplayPanel(panelSettings);
			break;
	}
	return 0;
}


/*===========================================================================*/
/* Function: configureGenerator
/* Purpose:  Configure the generator
/*===========================================================================*/
int configureGenerator(void)
{
	ViStatus status = VI_SUCCESS;
	
	CHECKERR(rscmwgprf_ConfigureGeneratorMode (instrSession, 1, RSCMWGPRF_VAL_GENMODE_CW));
	CHECKERR(rscmwgprf_ConfigureGeneratorStandAloneScenario (instrSession, 1, RSCMWGPRF_VAL_ANALYZER_CONN_RF1C, RSCMWGPRF_VAL_ANALYZER_SAL_CONV_RX1));
	CHECKERR(rscmwgprf_ConfigureGeneratorMode (instrSession, 1, RSCMWGPRF_VAL_GENMODE_LIST));
	
	CHECKERR(rscmwgprf_ConfigureGeneratorListRange (instrSession, 1, LIST_START, LIST_STOP));
	CHECKERR(rscmwgprf_ConfigureGeneratorList (instrSession, 1, LIST_LEN, freqArr, levArr, zeroArr, dwelArr, falseArr));
	
	CHECKERR(rscmwgprf_ConfigureGeneratorState (instrSession, 1, VI_TRUE));
	
	return status;
}

/*===========================================================================*/
/* Function: configureMeasurement
/* Purpose:  Configure the measurement
/*===========================================================================*/
int configureMeasurement(void)
{
	ViStatus status = VI_SUCCESS;
	CHECKERR(rscmwgprf_ConfigureAnalyzerStandAloneScenario (instrSession, 1, RSCMWGPRF_VAL_ANALYZER_CONN_RF1C, RSCMWGPRF_VAL_ANALYZER_SAL_CONV_RX1));
	CHECKERR(rscmwgprf_ConfigurePwrMeasListRange (instrSession, 1, VI_TRUE, 0, 29));
	CHECKERR(rscmwgprf_ConfigurePwrMeasParameters (instrSession, 1, 0.5e-3, 1e-3));
	CHECKERR(rscmwgprf_ConfigurePwrMeasList (instrSession, 1, 30, freqArr, zeroArr));
	CHECKERR(rscmwgprf_ConfigurePwrMeasStatistics (instrSession, 1,
											  RSCMWGPRF_VAL_REPETITION_SINGLE, 20));
	CHECKERR(rscmwgprf_ConfigurePwrMeasTrigger (instrSession, 1, "IF Power",
										   RSCMWGPRF_VAL_TRIGSLOPE_RISING,
										   -30.0, 0.25E-3,
										   RSCMWGPRF_VAL_TRIGMODE_ONCE, 1.0));
	CHECKERR(rscmwgprf_ConfigurePwrMeasTriggerGap (instrSession, 1, 1.0e-2));
	
	return status;
}

/*===========================================================================*/
/* Function: measurePower
/* Purpose:  Start measurement
/*===========================================================================*/
int measurePower(void)
{
	ViStatus status = VI_SUCCESS;
	ViInt32 res, rel;
	
	CHECKERR(rscmwgprf_PwrMeasInit (instrSession, 1));
	
	CHECKERR(rscmwgprf_FetchPwrMeas (instrSession, 1, RSCMWGPRF_VAL_RESULT_CURRENT,
								RSCMWGPRF_VAL_DETECTOR_RMS, 30, &rel, rmsArr, &res));
	CHECKERR(rscmwgprf_FetchPwrMeas (instrSession, 1, RSCMWGPRF_VAL_RESULT_CURRENT,
								RSCMWGPRF_VAL_DETECTOR_MIN, 30, &rel, minArr, &res));
	CHECKERR(rscmwgprf_FetchPwrMeas (instrSession, 1, RSCMWGPRF_VAL_RESULT_CURRENT,
								RSCMWGPRF_VAL_DETECTOR_MAX, 30, &rel, maxArr, &res));
	
	return status;
}


/*===========================================================================*/
/* Function: checkError
/* Purpose:  If passed status indicates an failure, the error message will
/*           be displayed.
/*===========================================================================*/
ViStatus checkError (ViStatus status)
{
    ViChar  error_message [STRING_LENGTH];
    ViChar  error_buffer  [STRING_LENGTH*2];
    ViChar* p2buf;
    ViInt32 error;
    
    if (status < VI_SUCCESS)
    {
        /* Converts a status code returned by an instrument driver function into a user-readable string */
        rscmwgprf_error_message (instrSession, status, error_message);
        p2buf = error_buffer + sprintf (error_buffer, "Primary Error: 0x%08X, %s\n", status, error_message);
        
        
        /* This function reads an error code and a message from the instrument's error queue */
        rscmwgprf_error_query (instrSession, &error, error_message);
        
        SetWaitCursor (0);
        if (error != VI_SUCCESS)
        {
            sprintf (p2buf, "Secondary Error: 0x%08X, %s\n", error, error_message);
        }
        MessagePopup ("Error", error_buffer);
        
        /* close session */
        cleanup(VI_TRUE);
        
        /* enable buttons for configuration */
        EnableButtons(VI_TRUE);
    }
    return status;
}


/*===========================================================================*/
/* Function: EnableButtons
/* Purpose:  This function dis-/enables GUI while measuring/configuration.
/*===========================================================================*/
void EnableButtons(ViBoolean enable){

    SetCtrlAttribute (panelHandle, MAIN_START, ATTR_DIMMED,!enable);
	SetCtrlAttribute (panelHandle, MAIN_INSTR_DESC, ATTR_DIMMED,!enable);  
	SetCtrlAttribute (panelHandle, MAIN_IDQUERY, ATTR_DIMMED,!enable); 
	SetCtrlAttribute (panelHandle, MAIN_RESET, ATTR_DIMMED,!enable); 
	SetCtrlAttribute (panelHandle, MAIN_SETUP, ATTR_DIMMED,!enable); 
}


/*===========================================================================*/
/* Function: Cleanup
/* Purpose:  Closes the VISA session to the instrument and in case of error
/*           queries the error and shows the dialog box with the passed error
/*           message. In case Device Clear is requested, it is necessary to 
/*           set the argument deviceClear to VI_TRUE.
/*===========================================================================*/
void cleanup (ViBoolean deviceClear)
{

    /* Device Clear is a low-level command and should be used in case the
     * instrument is waiting for Operation Complete to cancel the wait.
     * It is useful for instance in case of incorrect external trigger
     * when the instrument does not respond to any other command because of
     * waiting for trigger.
     */
    if (deviceClear)
    {
        viClear (instrSession);
        viPrintf (instrSession, "*CLS\n");
    }
    
    /* close instrument session */
    rscmwgprf_close (instrSession);
    instrSession = VI_NULL;
    
    /* enable GUI */
    EnableButtons (1);
    /* enable mouse events*/
    SetWaitCursor (0);
}


/*===========================================================================*/
/* Function: loadDeagults
/* Purpose:  This function fill up table with default values.
/*===========================================================================*/
void loadDefaults(void)
{
	InsertTableRows (panelSettings, LIST_FREQ, -1, LIST_LEN - 1, VAL_USE_MASTER_CELL_TYPE);
	for(int i=1; i <= LIST_LEN; i++) 
	{
		SetTableCellAttribute (panelSettings, LIST_FREQ, MakePoint(1,i), ATTR_CTRL_VAL, freqArr[i-1]/1e6);
		SetTableCellAttribute (panelSettings, LIST_FREQ, MakePoint(2,i), ATTR_CTRL_VAL, "MHz");
		SetTableCellAttribute (panelSettings, LIST_FREQ, MakePoint(3,i), ATTR_CTRL_VAL, levArr[i-1]);
		SetTableCellAttribute (panelSettings, LIST_FREQ, MakePoint(4,i), ATTR_CTRL_VAL, "dBm");
	}
}


/*===========================================================================*/
/* Function: closeList  Callback
/* Purpose:  Update values in array and hide configuration panel.
/*===========================================================================*/
int CVICALLBACK closeList (int panel, int control, int event,
		void *callbackData, int eventData1, int eventData2)
{
	switch (event)
	{
		case EVENT_COMMIT:
			HidePanel(panel);
			
			/*update arrays*/
			for(int i=0; i < LIST_LEN; i++)
			{
				 GetTableCellAttribute (panel, LIST_FREQ, MakePoint(1,i+1), ATTR_CTRL_VAL, &freqArr[i]);
				 freqArr[i] *= 1e6;
				 GetTableCellAttribute (panel, LIST_FREQ, MakePoint(3,i+1), ATTR_CTRL_VAL, &levArr[i]);
			}
			break;
	}
	return 0;
}

