/**************************************************************************/
/* LabWindows/CVI User Interface Resource (UIR) Include File              */
/* Copyright (c) National Instruments 2012. All Rights Reserved.          */
/*                                                                        */
/* WARNING: Do not add to, delete from, or otherwise modify the contents  */
/*          of this include file.                                         */
/**************************************************************************/

#include <userint.h>

#ifdef __cplusplus
    extern "C" {
#endif

     /* Panels and Controls: */

#define  LIST                             1
#define  LIST_FREQ                        2       /* control type: table, callback function: (none) */
#define  LIST_CLOSE                       3       /* control type: command, callback function: closeList */

#define  MAIN                             2
#define  MAIN_INSTR_DESC                  2       /* control type: string, callback function: (none) */
#define  MAIN_RESET                       3       /* control type: radioButton, callback function: (none) */
#define  MAIN_IDQUERY                     4       /* control type: radioButton, callback function: (none) */
#define  MAIN_POW_GRAPH                   5       /* control type: graph, callback function: powSelelect */
#define  MAIN_START                       6       /* control type: command, callback function: startMeas */
#define  MAIN_EXIT                        7       /* control type: command, callback function: exitApp */
#define  MAIN_POW_TABLE                   8       /* control type: table, callback function: (none) */
#define  MAIN_DECORATION                  9       /* control type: deco, callback function: (none) */
#define  MAIN_DECORATION_2                10      /* control type: deco, callback function: (none) */
#define  MAIN_SETUP                       11      /* control type: command, callback function: setupCall */


     /* Menu Bars, Menus, and Menu Items: */

          /* (no menu bars in the resource file) */


     /* Callback Prototypes: */

int  CVICALLBACK closeList(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK exitApp(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK powSelelect(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK setupCall(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);
int  CVICALLBACK startMeas(int panel, int control, int event, void *callbackData, int eventData1, int eventData2);


#ifdef __cplusplus
    }
#endif
