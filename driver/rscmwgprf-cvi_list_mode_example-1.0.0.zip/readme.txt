README.TXT

Rohde&Schwarz CMWGPRF Program Example for LabWindows/CVI

Listmode example

Version: 1.1, 8/2012

Contents:

1.0  Introduction

2.0  Prerequisites

3.0  How to use this example
3.1  Using the CVI instrument driver
3.2  Using the VXI Plug&Play driver instead of LabWindows/CVI source code

4.0  Known Defects

5.0  Revision History

6.0  Example Files
----------------------------------------------------------------------------

1.0  Introduction

This example explains how to use the CVI Instrument driver.

2.0  Prerequisites

- National Instruments LabWindows/CVI 9.0 (or higher)
- National Instruments NI-488.2 Software 1.60 (or higher) (GPIB only)
- National Instruments VISA 3.0 or Agilent I/O Library 14 (or higher)
- rscmwgprf LabWindows/CVI Instrument Driver

3.0  How to use this example

3.1 Using the LabWindows/CVI instrument driver

Unzip the LabWindows/CVI driver and the example and create a new project.

Add the example files:
	rscmwgprf_list_mode_example.c
	rscmwgprf_list_mode_example.h
	rscmwgprf_list_mode_example.uir
Add the driver sources:
	rscmwgprf.c
	rscmwgprf.h
	rscmwgprf.fp
	rscmwgprf_attributes.c
	rscmwgprf_attributes.h
	rscmwgprf_utility.h
	rscmwgprf_utility.c
	rsidr_core.c
	rsidr_core.h

Make an executable file and run it. 
To use the example, fill in the Resource String (by default it is 
GPIB0::20::INSTR). Press Settings button to configure frequency and level. 
To start measurement press the Start button. Results are shown in table. 
You may press Start button again to start new measurement. Example could 
be exited by closing the window.

3.2 Using the VXI Plug&Play driver instead of LabWindows/CVI source code

For faster load time for your project install the RSCMWGPRF VXIPlug&Play driver.

LabWindows/CVI (R) by default will attempt to load the source version
of the instrument driver. To load the dll you must include the front panel file 
rscmwgprf.fp in your project. This file can be found in the ~\WinNT\rscmwgprf 
directory. Do not include rscmwgprf.c in your project. You must also provide 
an include path for rscmwgprf.h. This is done by adding the directory 
~\WinNT\include to the include paths (LabWindows/CVI Project Option menu) if 
you have not already done so. The ~ refers to the directory in the VXIPNPPATH 
variable. By default this is set to C:\Program Files\IVI Foundation\VISA.

Include the example files:
	rscmwgprf_list_mode_example.c
	rscmwgprf_list_mode_example.h
	rscmwgprf_list_mode_example.uir
Make an executable file and run it. 
To use the example, fill in the Resource String (by default it is 
GPIB0::20::INSTR). Press Settings button to configure frequency and level. 
To start measurement press the Start button. Results are shown in table. 
You may press Start button again to start new measurement. Example could 
be exited by closing the window.

4.0  Known Defects

none

5.0  Revision History

  1.0 12/2009, Petr Zavodny
      Created.
  1.1 8/2012, Petr Zavodny
      Routing settings function replaced according to driver update.  

6.0  Example Files

rscmwgprf_list_mode_example.c   - Example source code
rscmwgprf_list_mode_example.h   - Example header file
rscmwgprf_list_mode_example.uir - Example GUI
readme.txt                     	- this file

-----------------------------------------------------------------------------
Should you have any technical questions please contact 
the hotline of Rohde & Schwarz Vertriebs-GmbH
Rohde & Schwarz Support Center
e-mail: CustomerSupport@rohde-schwarz.com
-----------------------------------------------------------------------------
