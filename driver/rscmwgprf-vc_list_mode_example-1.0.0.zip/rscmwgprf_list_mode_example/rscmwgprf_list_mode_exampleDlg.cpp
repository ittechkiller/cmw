
// rscmwgprf_list_mode_exampleDlg.cpp : implementation file
//

#include "stdafx.h"
#include "rscmwgprf_list_mode_example.h"
#include "rscmwgprf_list_mode_exampleDlg.h"
#include "afxdialogex.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#endif

#define CHECKERR(fcal) if ((rscmwgprf_status = fcal) < 0)\
					   {\
							cleanup(VI_FALSE);\
							return;\
					   }


/*Default values of frequency list [Hz]*/
double freqArr[] = {1e9, 1e9, 1e9, 1e9, 1e9, 1e9, 1e9, 1e9, 1e9, 1e9,
					  2e9, 2e9, 2e9, 2e9, 2e9, 2e9, 2e9, 2e9, 2e9, 2e9,
					  3e9, 3e9, 3e9, 3e9, 3e9, 3e9, 3e9, 3e9, 3e9, 3e9
					 };
/*Default values of level(RMS) list [dBm]*/
double levArr[] = {0, -3, -6, -9, -12, -15, -18, -21, -24, -27, 
					 0, -3, -6, -9, -12, -15, -18, -21, -24, -27, 
					 0, -3, -6, -9, -12, -15, -18, -21, -24, -27
					};
/*Default values of Dwell time list [dBm]*/  
double dwelArr[] = {1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3,
					  1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3,
					  1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3, 1e-3
					 };

double zeroArr[] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
					  0, 0, 0, 0, 0, 0, 0, 0, 0, 0,
					  0, 0, 0, 0, 0, 0, 0, 0, 0, 0
					 };

ViBoolean falseArr[] = {false, false, false, false, false, false, false, false, false, false,
					  false, false, false, false, false, false, false, false, false, false,
					  false, false, false, false, false, false, false, false, false, false
					 };

// Crscmwgprf_list_mode_exampleDlg dialog

Crscmwgprf_list_mode_exampleDlg::Crscmwgprf_list_mode_exampleDlg(CWnd* pParent /*=NULL*/)
	: CDialogEx(Crscmwgprf_list_mode_exampleDlg::IDD, pParent)
	, m_resName(_T("TCPIP::192.168.5.120::INST"))
	, m_IDQuery(TRUE)
	, m_reset(TRUE)
{
	m_hIcon = AfxGetApp()->LoadIcon(IDR_MAINFRAME);
}

void Crscmwgprf_list_mode_exampleDlg::DoDataExchange(CDataExchange* pDX)
{
	CDialogEx::DoDataExchange(pDX);
	DDX_Text(pDX, IDC_RES_NAME, m_resName);
	DDX_Check(pDX, IDC_ID_QUERY, m_IDQuery);
	DDX_Check(pDX, IDC_RESET, m_reset);
	DDX_Control(pDX, IDC_RESULTS, m_results);
}

BEGIN_MESSAGE_MAP(Crscmwgprf_list_mode_exampleDlg, CDialogEx)
	ON_WM_PAINT()
	ON_WM_QUERYDRAGICON()
	ON_BN_CLICKED(IDOK, &Crscmwgprf_list_mode_exampleDlg::OnBnClickedOk)
	ON_LBN_SELCHANGE(IDC_RESULTS, &Crscmwgprf_list_mode_exampleDlg::OnLbnSelchangeResults)
END_MESSAGE_MAP()


// Crscmwgprf_list_mode_exampleDlg message handlers

BOOL Crscmwgprf_list_mode_exampleDlg::OnInitDialog()
{
	int i=0;
	CString str;	

	CDialogEx::OnInitDialog();

	// Set the icon for this dialog.  The framework does this automatically
	//  when the application's main window is not a dialog
	SetIcon(m_hIcon, TRUE);			// Set big icon
	SetIcon(m_hIcon, FALSE);		// Set small icon

	// TODO: Add extra initialization here
	str.Format(_T("num       Frequency [Hz]          RMS [dBm]       Min [dBm]       Max [dBm]"), i+1, freqArr[i]);
	m_results.AddString(str);	
	for(i=0; i<30; i++)
	{		
		str.Format(_T("%2d          %1.2e                      -                   -                   -"), i+1, freqArr[i], 12.3, 13.4, 14.5 );
		m_results.AddString(str);
	}
	
	return TRUE;  // return TRUE  unless you set the focus to a control
}

// If you add a minimize button to your dialog, you will need the code below
//  to draw the icon.  For MFC applications using the document/view model,
//  this is automatically done for you by the framework.

void Crscmwgprf_list_mode_exampleDlg::OnPaint()
{
	if (IsIconic())
	{
		CPaintDC dc(this); // device context for painting

		SendMessage(WM_ICONERASEBKGND, reinterpret_cast<WPARAM>(dc.GetSafeHdc()), 0);

		// Center icon in client rectangle
		int cxIcon = GetSystemMetrics(SM_CXICON);
		int cyIcon = GetSystemMetrics(SM_CYICON);
		CRect rect;
		GetClientRect(&rect);
		int x = (rect.Width() - cxIcon + 1) / 2;
		int y = (rect.Height() - cyIcon + 1) / 2;

		// Draw the icon
		dc.DrawIcon(x, y, m_hIcon);
	}
	else
	{
		CDialogEx::OnPaint();
	}
}

// The system calls this function to obtain the cursor to display while the user drags
//  the minimized window.
HCURSOR Crscmwgprf_list_mode_exampleDlg::OnQueryDragIcon()
{
	return static_cast<HCURSOR>(m_hIcon);
}



void Crscmwgprf_list_mode_exampleDlg::OnBnClickedOk()
{	
	long rel, count;
	double rmsArr[30];
	double minArr[30];
	double maxArr[30];
	int i;
	CString str;
	
	USES_CONVERSION;
		
	UpdateData ();
	HCURSOR cur = LoadCursor ( NULL, IDC_WAIT );
	SetCursor (cur);

	CHECKERR(rscmwgprf_init ((char *) ((LPCTSTR) W2A(m_resName.LockBuffer())), VI_TRUE, VI_TRUE, &m_InstrSession));

	CHECKERR(rscmwgprf_ConfigureGeneratorMode (m_InstrSession, 1, RSCMWGPRF_VAL_GENMODE_CW));
	CHECKERR(rscmwgprf_ConfigureGeneratorStandAloneScenario (m_InstrSession, 1, RSCMWGPRF_VAL_ANALYZER_CONN_RF1C, RSCMWGPRF_VAL_ANALYZER_SAL_CONV_RX1));
	CHECKERR(rscmwgprf_ConfigureGeneratorMode (m_InstrSession, 1, RSCMWGPRF_VAL_GENMODE_LIST));
	
	CHECKERR(rscmwgprf_ConfigureGeneratorListRange (m_InstrSession, 1, 0, 29));
	CHECKERR(rscmwgprf_ConfigureGeneratorList (m_InstrSession, 1, 30, freqArr, levArr, zeroArr, dwelArr, falseArr));
	
	CHECKERR(rscmwgprf_ConfigureGeneratorState (m_InstrSession, 1, VI_TRUE));

	CHECKERR(rscmwgprf_ConfigureAnalyzerStandAloneScenario (m_InstrSession, 1, RSCMWGPRF_VAL_ANALYZER_CONN_RF1C, RSCMWGPRF_VAL_ANALYZER_SAL_CONV_RX1));
	CHECKERR(rscmwgprf_ConfigurePwrMeasListRange (m_InstrSession, 1, VI_TRUE, 0, 29));
	CHECKERR(rscmwgprf_ConfigurePwrMeasParameters (m_InstrSession, 1, 0.5e-3, 1e-3));
	CHECKERR(rscmwgprf_ConfigurePwrMeasList (m_InstrSession, 1, 30, freqArr, zeroArr));
	CHECKERR(rscmwgprf_ConfigurePwrMeasStatistics (m_InstrSession, 1,
											  RSCMWGPRF_VAL_REPETITION_SINGLE, 20));
	CHECKERR(rscmwgprf_ConfigurePwrMeasTrigger (m_InstrSession, 1, "IF Power",
										   RSCMWGPRF_VAL_TRIGSLOPE_RISING,
										   -30.0, 0.25E-3,
										   RSCMWGPRF_VAL_TRIGMODE_ONCE, 1.0));
	CHECKERR(rscmwgprf_ConfigurePwrMeasTriggerGap (m_InstrSession, 1, 1.0e-2));

	CHECKERR(rscmwgprf_PwrMeasInit (m_InstrSession, 1));
	
	CHECKERR(rscmwgprf_FetchPwrMeas (m_InstrSession, 1, RSCMWGPRF_VAL_RESULT_CURRENT,
								RSCMWGPRF_VAL_DETECTOR_RMS, 30, &rel, rmsArr, &count));
	CHECKERR(rscmwgprf_FetchPwrMeas (m_InstrSession, 1, RSCMWGPRF_VAL_RESULT_CURRENT,
								RSCMWGPRF_VAL_DETECTOR_MIN, 30, &rel, minArr, &count));
	CHECKERR(rscmwgprf_FetchPwrMeas (m_InstrSession, 1, RSCMWGPRF_VAL_RESULT_CURRENT,
								RSCMWGPRF_VAL_DETECTOR_MAX, 30, &rel, maxArr, &count));
		
	m_results.ResetContent();
	str.Format(_T("num       Frequency [Hz]          RMS [dBm]       Min [dBm]       Max [dBm]"));
	m_results.AddString(str);	
	for(i=0; i<30; i++)
	{		
		str.Format(_T("%2d          %1.2e                  %#2.2f               %#2.2f               %#2.2f"), i+1, freqArr[i], rmsArr[i], minArr[i], maxArr[i] );
		m_results.AddString(str);
	}

	cleanup(false);
	
	UpdateData(true);	
	cur = LoadCursor (NULL, IDC_ARROW);
	SetCursor (cur);
}


void Crscmwgprf_list_mode_exampleDlg::OnLbnSelchangeResults()
{
	// TODO: Add your control notification handler code here
}


/*===========================================================================*/
/* Function: Cleanup
/* Purpose:  Closes the VISA session to the instrument and in case of error
/*           queries the error and shows the dialog box with error message.
/*           In case Device Clear is requested, it is necessary to set the
/*           argument deviceClear to VI_TRUE.
/*===========================================================================*/
void Crscmwgprf_list_mode_exampleDlg::cleanup(ViBoolean deviceClear)
{
	if (rscmwgprf_status < 0)
	{
		ViChar      error_message[256];
		ViStatus    temp_status;
		CString		message;
		CString		error_string;
		
		/* Query the error message from the instrument driver. This
		 * function gets the error message for VISA and driver failures
		 */
		temp_status = rscmwgprf_error_message(m_InstrSession, rscmwgprf_status, error_message);
		
		if (temp_status == VI_WARN_UNKNOWN_STATUS)
		{
			/* Query the error message from the instrument. This
			 * function gets the error message directly from instrument, like
			 * execution error, out of range error etc.
			 */
			rscmwgprf_error_query(m_InstrSession, &temp_status, error_message);
		}
		error_string = error_message;
		message.Format (_T ("Error 0x%8X occured:\n\n%s"), rscmwgprf_status, error_string);
		AfxMessageBox (message, MB_OK | MB_ICONSTOP); 
	}
	
	/* Device Clear is a low-level command and should be used in case the
	 * instrument is waiting for Operation Complete to cancel the wait.
	 * It is useful for instance in case of incorrect external trigger
	 * when the instrument does not respond to any other command because of
	 * waiting for trigger.
	 */
	if (deviceClear)
	{
		viClear (m_InstrSession);
		viPrintf (m_InstrSession, "*CLS\n");
	}
	
	if (m_InstrSession != NULL)
		rscmwgprf_close (m_InstrSession);

	//GetDlgItem(IDC_SEARCH)->EnableWindow(FALSE);

	HCURSOR cur = LoadCursor ( NULL, IDC_ARROW );
	SetCursor (cur);
}