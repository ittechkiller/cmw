
// rscmwgprf_list_mode_exampleDlg.h : header file
//

#pragma once
#include "afxwin.h"


// Crscmwgprf_list_mode_exampleDlg dialog
class Crscmwgprf_list_mode_exampleDlg : public CDialogEx
{
// Construction
public:	
	Crscmwgprf_list_mode_exampleDlg(CWnd* pParent = NULL);	// standard constructor	

// Dialog Data
	enum { IDD = IDD_RSCMWGPRF_LIST_MODE_EXAMPLE_DIALOG };

	protected:
	virtual void DoDataExchange(CDataExchange* pDX);	// DDX/DDV support

	
// Implementation
protected:
	HICON m_hIcon;

	// Generated message map functions
	virtual BOOL OnInitDialog();
	afx_msg void OnPaint();
	afx_msg HCURSOR OnQueryDragIcon();
	DECLARE_MESSAGE_MAP();
public:
	ViSession m_InstrSession;
	ViStatus rscmwgprf_status;
	void cleanup(ViBoolean deviceClear);
	afx_msg void OnBnClickedOk();
	CString m_resName;
	BOOL m_IDQuery;
	BOOL m_reset;
	CListBox m_results;
	afx_msg void OnBnClickedSettings();
	afx_msg void OnLbnSelchangeResults();	
};
