
// stdafx.cpp : source file that includes just the standard includes
// rscmwgprf_list_mode_example.pch will be the pre-compiled header
// stdafx.obj will contain the pre-compiled type information

#include "stdafx.h"


